<?php

namespace App\Listeners;

use App\Events\CreateNewUser;
use App\Mail\VerificationMail;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;

class SendVerificationMail
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     * @param CreateNewUser $event
     */
    public function handle(CreateNewUser $event): void
    {
        $newUser = $event->user;
        $verificationURL = URL::temporarySignedRoute('verifyUser',
            now()->addMinutes(5),
            [
                'email' => $newUser->email,
                'token' => $newUser->remember_token
            ]
        );
        Mail::to($newUser->email)->send(new VerificationMail($verificationURL));

    }
}
