<?php

namespace App\Listeners;

use App\Events\VerifyNewUser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class ActivateUser
{
    /**
     * Create the event listener.
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     */
    public function handle(VerifyNewUser $event): void
    {
        $event->user->is_active = 1;
        $event->user->markEmailAsVerified();
        $event->user->save();
    }
}
