<?php

namespace App\Http\Controllers;

use App\Events\VerifyNewUser;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ActivateUserController extends Controller
{
    public function verifyUser($email, $token, Request $request)
    {
        Auth::logout();
        $userData = User::where('email', $email)->firstOrFail();
        if (isset($userData) && $userData->remember_token === $token) {
            if ($request->hasValidSignature()) {
                event(new VerifyNewUser($userData));
                return view('welcome', compact('userData'));
            }
            return view('linkExpired', compact('email'));
        }
        return abort(401, "Unauthorised access");
    }


}
