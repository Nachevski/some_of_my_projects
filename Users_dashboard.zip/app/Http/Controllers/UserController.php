<?php

namespace App\Http\Controllers;

use App\Events\CreateNewUser;
use App\Http\Requests\UserRequest;
use App\Listeners\SendVerificationMail;
use App\Mail\VerificationMail;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::where('type', 'regular')->get();
        return response()->json($users);
    }

    /**
     * Store a newly created resource in storage.
     * @param UserRequest $request
     */
    public function store(UserRequest $request)
    {
        $newUser = new User();
        $newUser->username = $request->username;
        $newUser->email = $request->email;
        $newUser->password = Hash::make($request->password);
        $newUser->setRememberToken(Str::random(60));
        $newUser->created_at = now();
        $newUser->updated_at = now();
        $newUser->save();
//        CALL EVENT
        event(new CreateNewUser($newUser));
        return response()->json([
            'status' => true,
            'statusMessage' => "Successfully created username: $request->username"
        ]);
    }

    public function resendVerificationLink(Request $request)
    {
        $user = User::where('email', $request->email)->firstOrFail();
        event(new CreateNewUser($user));
        return back()->with([
            'statusMessage' => "New verification code was send successfully"
        ]);
    }

    /**
     * Update the specified resource in storage.
     * @param User $user
     * @return \Illuminate\Http\JsonResponse
     */
    public function deactivate(User $user)
    {
        $user->is_active = 0;
        $user->save();
        return response()->json([
            'status' => true,
            'statusMessage' => "Successfully deactivated user: $user->username"]);
    }

    /**
     * Remove the specified resource from storage.
     * @param User $userID
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(User $userID)
    {
        $userID->delete();
        return response()->json([
            'status' => true,
            'statusMessage' => "Successfully deleted username: $userID->username"
        ]);
    }
}
