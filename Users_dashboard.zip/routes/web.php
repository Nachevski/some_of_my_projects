<?php

use App\Http\Controllers\ActivateUserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/logout', [AuthenticatedSessionController::class, 'destroy']);

Route::get('/', function () {
    return redirect('/login');
});

Route::middleware('auth')->group(function () {
    Route::view('/user-panel', 'index')->middleware('isUserActive')
        ->name('user-panel');
    Route::middleware('userPrivileges')->group(function () {
        Route::view('/dashboard', 'dashboard')
            ->name('dashboard');
    });
});

Route::post('/resendVerificationLink', [UserController::class, 'resendVerificationLink'])
    ->name('resendVerificationLink');

Route::get('validation/{email}/{token}', [ActivateUserController::class, 'verifyUser'])
    ->name('verifyUser');


require __DIR__ . '/auth.php';
