<div style="text-align: center">
    <h1>Hello, <?php echo e($userData->username); ?></h1>
    <h4>Your account is active, You can login now!</h4>
    <a href="/login" class="btn btn-success">Login</a>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_28/Challenge_28/resources/views/welcome.blade.php ENDPATH**/ ?>