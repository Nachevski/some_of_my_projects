<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->make('custom-layout.components.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title>Link Expired</title>
</head>
<body>
<div class="container-fluid mt-5">
    <div class="row">
        <div class="col-8 mx-auto text-center">
            <?php echo $__env->make('custom-layout.components.success-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(!Session::has('statusMessage')): ?>
                <h1>Link has expired!</h1>
                <h4>Click on the button to resend new verification link</h4>
                <form action="<?php echo e(route('resendVerificationLink')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" value="<?php echo e($email); ?>" name="email" hidden>
                    <button type="submit" class="btn btn-success">Resend</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
<?php /**PATH /home/nachevski/Desktop/Challenge_28/Challenge_28/resources/views/linkExpired.blade.php ENDPATH**/ ?>