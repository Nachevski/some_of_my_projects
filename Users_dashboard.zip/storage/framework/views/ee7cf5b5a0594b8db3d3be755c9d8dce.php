<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto">
                <?php echo $__env->make('custom-layout.components.success-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#createModal">Create new
                </button>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Username</th>
                        <th scope="col">Email</th>
                        <th scope="col">Type</th>
                        <th scope="col">Status</th>
                        <th scope="col" style="width:150px">Actions</th>
                    </tr>
                    </thead>
                    <tbody id="users">
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php echo $__env->make('custom-layout.components.create-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_28/Challenge_28/resources/views/dashboard.blade.php ENDPATH**/ ?>