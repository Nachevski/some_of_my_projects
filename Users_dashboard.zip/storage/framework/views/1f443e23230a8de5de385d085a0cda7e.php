<?php if(Session::has('statusMessage')): ?>
    <div class="alert alert-success text-center" role="alert">
        <?php echo e(Session::get('statusMessage')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/nachevski/Desktop/Challenge_28/Challenge_28/resources/views/custom-layout/components/success-msgs.blade.php ENDPATH**/ ?>