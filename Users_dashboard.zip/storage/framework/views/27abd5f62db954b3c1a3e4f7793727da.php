<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto text-center">
                <h1>Hello, <?php echo e(Auth::user()->username); ?></h1>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_28/Challenge_28/resources/views/index.blade.php ENDPATH**/ ?>