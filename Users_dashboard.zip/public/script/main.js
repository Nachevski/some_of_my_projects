$(function () {
    loadUsers()
    $('#wait ').hide();

    function loadUsers() {
        $.get('api/users', function (data) {
            let table = $('#users').empty()
            console.log(data)
            data.forEach(element => {
                let row = `<tr>
                                <td>${element.username}</td>
                                <td>${element.email}</td>
                                <td>${element.type}</td>
                                <td${(element.is_active) ? ' class="text-success fw-bold">Is Active' : ' class="text-danger fw-bold">Not active'}</td>
                                <td class="d-flex" style="width: fit-content">
                                    <button data-id="${element.id}" class="btn btn-danger me-2 btn-delete">Delete</button>                                    ${(element.is_active) ? `<button data-id="${element.id}" class="btn btn-info me-2 btn-deactivate">Deactivate</button>` : ''}
                                </td>
                            </tr>`
                table.append(row);
            })

            $('.btn').on('click', function (e) {
                if ($(this).hasClass('btn-delete')) {
                    deleteRecord($(this).data('id'), $(this))
                } else if ($(this).hasClass('btn-deactivate')) {
                    deactivateUSer($(this).data('id'))
                }
            })
        })
    }

    function deleteRecord(userID, rowRecord) {
        $.ajax({
            url: `/api/users/${userID}`,
            type: 'DELETE',
            success: function (response) {
                showResponseStatus(response)
                rowRecord.closest('tr').remove()
            }
        });
    }

    $('#createForm').submit(function (e) {
        e.preventDefault();
        $('#wait ')
            .fadeIn(500)
        $.ajax({
            url: `api/users`,
            type: 'POST',
            data: $('#createForm').serialize(),
        }).done(function (response) {
            if (!response.status) {
                let errorShow = $('#createModal .errors').empty()
                errorShow.append(generateErrors(response.errors))
            } else {
                $('#createModal').modal('toggle');
                $('#createForm input').val('');
                $('#wait ')
                    .fadeOut(100)
                showResponseStatus(response)
                loadUsers();
            }
        })
    })

    function deactivateUSer(userID) {
        $.ajax({
            url: `/api/users/${userID}/deactivate`,
            type: 'PUT',
        }).done(function (response) {
            showResponseStatus(response)
            loadUsers();
        })
    }

    function showResponseStatus(response) {
        $('.alert ')
            .fadeIn(100)
            .html(response.message)
            .fadeOut(10000)
    }

    function generateErrors(errors) {
        let report = Object.values(errors)
        let ul = '';
        report.forEach(element => {
            ul += `<li>${element}</li>`
        })
        return ul;
    }
})
