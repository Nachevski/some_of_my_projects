@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto text-center">
                <h1>Hello, {{$userData->username}}</h1>
                <h4>Your account is active, You can login now!</h4>
                <a href="/login" class="btn btn-success">Login</a>
            </div>
        </div>
    </div>

@endsection
