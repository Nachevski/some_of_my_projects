@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto">
                @include('custom-layout.components.success-msgs')
                <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#createModal">Create new
                </button>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Username</th>
                        <th scope="col">Email</th>
                        <th scope="col">Type</th>
                        <th scope="col">Status</th>
                        <th scope="col" style="width:150px">Actions</th>
                    </tr>
                    </thead>
                    <tbody id="users">
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('custom-layout.components.create-modal')
@endsection
