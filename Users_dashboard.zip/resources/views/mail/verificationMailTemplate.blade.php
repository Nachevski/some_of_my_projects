Click on the link to activate your account: <a href="{{$verificationURL}}">Link</a>
