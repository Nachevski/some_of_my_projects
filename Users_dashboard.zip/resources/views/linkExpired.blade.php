@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto text-center">
                @include('custom-layout.components.success-msgs')
                @if(!Session::has('statusMessage'))
                    <h1>Link has expired!</h1>
                    <h4>Click on the button to resend new verification link</h4>
                    <form action="{{route('resendVerificationLink')}}" method="POST">
                        @csrf
                        <input type="text" value="{{$email}}" name="email" hidden>
                        <button type="submit" class="btn btn-success">Resend</button>
                    </form>
                @endif
            </div>
        </div>
    </div>

@endsection
