@if(Session::has('statusMessage'))
    <div class="alert alert-success text-center" role="alert">
        {{ Session::get('statusMessage') }}
    </div>
@endif
