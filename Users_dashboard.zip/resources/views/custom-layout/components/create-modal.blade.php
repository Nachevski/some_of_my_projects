<!-- Modal -->
<div class="modal fade" id="createModal" tabindex="-1" aria-labelledby="editModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Create New User</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-danger errors">
                </div>
                <form id="createForm">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control username" name="username">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control email" name="email">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control password" name="password">
                    </div>
                    <div class="text-end">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add New User</button>
                    </div>
                </form>
            </div>
            <div id="wait" class="position-absolute top-0 bottom-0 start-0 end-0 bg-dark bg-opacity-75 rounded"
                 style="display: none">
                <div class="d-flex justify-content-center align-items-center h-100 flex-column text-light text-center">
                    <i class="fa-solid fa-envelope-open-text mb-5" style="font-size: 75px"></i>
                    <h2 class="m-0">Sending verification mail</h2>
                    <h2>Please wait...</h2>
                </div>
            </div>
        </div>
    </div>

</div>
