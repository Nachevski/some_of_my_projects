@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto text-center">
                <h1>Hello, {{Auth::user()->username}}</h1>
            </div>
        </div>
    </div>

@endsection
