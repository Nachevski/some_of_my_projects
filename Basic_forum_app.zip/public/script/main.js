$(document).ready(function () {
    //***************************************
    //CHANGE IF YOU USE DIFFERENT SERVER CONF
    const LOCALHOST = 'http://127.0.0.1';
    const PORT = '8000';
    const GET_COMMENT_API = 'get-comment';
    const GET_DISCUSSION_API = 'get-discussion';
    const DISCUSSION_VALIDATE_API = 'discussion/validate';
    const COMMENT_VALIDATE_API = 'comment/validate';
    //***************************************

    //PREVENTING A LINK TO EXECUTE WHEN CLICK BUTTONS NESTED IN <a> TAG
    $(document).on('click', function (e) {
        if (e.target.classList.contains('btn-delete-discussion') || e.target.classList.contains('btn-edit-discussion')) {
            e.preventDefault()
        }
    })

    //BTN DELETE DISCUSSION
    $('.btn-delete-discussion').on('click', function () {
        $('#deleteDiscussionForm').attr('action', `/discussion/delete/${$(this).data('id')}`)
    })

    //BTN DELETE COMMENT
    $('.btn-delete-comment').on('click', function () {
        $('#deleteCommentForm').attr('action', `/delete-comment/${$(this).data('id')}`)
    })

    //BTN EDIT COMMENT
    $('.btn-edit-comment').on('click', function (e) {
        let commentID = $(this).data('id')
        $.get(`${LOCALHOST}:${PORT}/${GET_COMMENT_API}/${commentID}`, function (data) {
            $('#editCommentForm #commentArea').text(data.data.comment)
            $('#editCommentForm').attr('action', `/update-comment/${commentID}`)
        })
    })

    //BTN EDIT DISCUSSION
    $('.btn-edit-discussion').on('click', function (e) {
        let discussionID = $(this).data('id')
        $.get(`${LOCALHOST}:${PORT}/${GET_DISCUSSION_API}/${discussionID}`, function (data) {
            $('#commentArea').text(data.data.comment)
            $('#editDiscussionForm').attr('action', `/update-discussion/${discussionID}`)
            $('#discussionTitle').val(data.data.title)
            $('#discussionDescription').text(data.data.description)
            $('#discussionCategories option[value="' + data.data.category_id + '"]').prop('selected', true)
        })
    })

    //NEW DISCUSSION FORM
    $('#newDiscussionForm').submit(function (e) {
        e.preventDefault()
        $('#newDiscussionModal .validationErrors').empty()
        const formData = $('#newDiscussionForm');
        let errors = ''
        //VALIDATE API CALL
        $.post(`${LOCALHOST}:${PORT}/${DISCUSSION_VALIDATE_API}`, formData.serialize(), function (data) {
            if (!data.success) {
                const result = Object.values(data.errors);
                result.forEach((element) => {
                    errors += `<li>${element[0]}</li>`
                })
                let child = `
                        <ul class="alert alert-danger" role="alert" id="errors">
                            <div class="ps-5">
                            ${errors}
                            </div>
                        </ul>`
                $('#newDiscussionModal .validationErrors').append(child)
                return false
            }
            formData.unbind('submit').submit()
        })
    })

    //EDIT DISCUSSION FORM
    $('#editDiscussionForm').submit(function (e) {
        e.preventDefault()
        $('#editDiscussionForm .validationErrors').empty()
        const formData = $('#editDiscussionForm');
        let errors = ''
        //VALIDATE API CALL
        $.post(`${LOCALHOST}:${PORT}/${DISCUSSION_VALIDATE_API}`, formData.serialize(), function (data) {
            if (!data.success) {
                const result = Object.values(data.errors);
                result.forEach((element) => {
                    errors += `<li>${element[0]}</li>`
                })
                let child = `
                        <ul class="alert alert-danger" role="alert" id="errors">
                            <div class="ps-5">
                            ${errors}
                            </div>
                        </ul>`
                $('#editDiscussionForm .validationErrors').append(child)
                return false
            }
            formData.unbind('submit').submit()
        })
    })

    //NEW COMMENT FORM
    $('#newCommentForm').submit(function (e) {
        e.preventDefault()
        $('#newCommentForm .validationErrors').empty()
        const formData = $('#newCommentForm');
        let errors = ''
        $.post(`${LOCALHOST}:${PORT}/${COMMENT_VALIDATE_API}`, formData.serialize(), function (data) {
            if (!data.success) {
                const result = Object.values(data.errors);
                result.forEach((element) => {
                    errors += `<li>${element[0]}</li>`
                })
                let child = `
                        <ul class="alert alert-danger" role="alert" id="errors">
                            <div class="ps-5">
                            ${errors}
                            </div>
                        </ul>`
                $('#newCommentForm .validationErrors').append(child)
                return false
            }
            formData.unbind('submit').submit()
        })
    })

    //EDIT COMMENT FORM
    $('#editCommentForm').submit(function (e) {
        e.preventDefault()
        $('#editCommentForm .validationErrors').empty()
        const formData = $('#editCommentForm');
        let errors = ''
        $.post(`${LOCALHOST}:${PORT}/${COMMENT_VALIDATE_API}`, formData.serialize(), function (data) {
            if (!data.success) {
                const result = Object.values(data.errors);
                result.forEach((element) => {
                    errors += `<li>${element[0]}</li>`
                })
                let child = `
                        <ul class="alert alert-danger" role="alert" id="errors">
                            <div class="ps-5">
                            ${errors}
                            </div>
                        </ul>`
                $('#editCommentForm .validationErrors').append(child)
                return false
            }
            formData.unbind('submit').submit()
        })
    })

});
