<?php

namespace App\Http\Controllers;

use App\Http\Requests\CommentRequest;
use App\Http\Resources\CommentResource;
use App\Models\Comment;
use App\Models\Discussion;
use Carbon\Traits\Date;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Ramsey\Uuid\Type\Time;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     * @param CommentRequest $request
     * @param Discussion $id
     */
    public function store(CommentRequest $request, Discussion $id)
    {

        Comment::create([
            'comment' => $request->comment,
            'user_id' => Auth::user()->id,
            'discussion_id' => $id->id,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now()
        ]);

        return redirect()->back()->with('successStatus', "Comment created successfully!");;
    }

    /**
     * Display the specified resource.
     */
    public function show(Comment $comment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Comment $id)
    {
        return new CommentResource($id);
    }

    /**
     * Update the specified resource in storage.
     * @param CommentRequest $request
     * @param Comment $id
     */
    public function update(CommentRequest $request, Comment $id)
    {
        $id->update($request->all());
        return redirect()->back()->with('successStatus', "Comment updated successfully!");

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Comment $id)
    {
        $id->delete();
        return redirect()->back()->with('successStatus', "Comment deleted successfully!");
    }

    public function checkData(CommentRequest $request)
    {
        if (isset($request)) {
            return response()->json(['success' => 'true']);
        }

    }
}
