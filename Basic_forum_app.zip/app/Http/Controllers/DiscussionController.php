<?php

namespace App\Http\Controllers;

use App\Http\Requests\CommentRequest;
use App\Http\Requests\DiscussionRequest;
use App\Http\Resources\DiscussionResource;
use App\Models\Category;
use App\Models\Discussion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class DiscussionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $discussions = Discussion::all()->where('is_approved', '=', '0');
        $categories = Category::all();
        return view('discussions-approve', compact('discussions', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     * @param DiscussionRequest $request
     */
    public function store(DiscussionRequest $request)
    {
        if ($request->file('photo')) {
            $storagePath = Storage::disk('local')->put('public/images', $request->file('photo'), );
            $storageName = basename($storagePath);
        } else {
            $storageName = 'no_image.jpg';
        }


        Discussion::create([
            'user_id' => Auth::user()->id,
            'title' => $request->title,
            'description' => $request->description,
            'category_id' => $request->category_id,
            'photoPath' => $storageName,
        ]);
        return redirect('/')->with('successStatus', 'New discussion opened succesfully! It must be approved first before showing!');
    }

    /**
     * Display the specified resource.
     */
    public function show(Discussion $id)
    {
        $categories = Category::all();

        $currentDiscussion = $id;
        return view('discussion-view', compact(['currentDiscussion', 'categories']));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Discussion $id)
    {
        return new DiscussionResource($id);
    }

    /**
     * Update the specified resource in storage.
     * @param DiscussionRequest $request
     * @param Discussion $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(DiscussionRequest $request, Discussion $id)
    {
        $id->update($request->all());
        return redirect()->back()->with('successStatus', "Discussion saved successfully!");
    }

    public function approve(Discussion $id)
    {
//        dd($id);
        $id->update(['is_approved' => '1']);
        return redirect()->back()->with('successStatus', "Approved Discussion: '$id->title'");

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Discussion $id)
    {
        $id->delete();
        return redirect()->back()->with('successStatus', "Deleted Discussion: '$id->title'");

    }

    public function checkData(DiscussionRequest $request)
    {
        if (isset($request)) {
            return response()->json(['success' => 'true']);
        }

    }
}
