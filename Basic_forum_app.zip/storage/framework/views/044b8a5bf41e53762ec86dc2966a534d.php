<i class="fa-regular fa-pen-to-square me-3 p2 btn-edit btn-edit-discussion"
   data-id="<?php echo e($discussion->id); ?>"
   data-bs-toggle="modal"
   data-bs-target="#editDiscussionModal"></i>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/edit-discussion-btn.blade.php ENDPATH**/ ?>