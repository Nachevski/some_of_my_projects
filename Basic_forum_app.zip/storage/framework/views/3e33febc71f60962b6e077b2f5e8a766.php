<?php $__env->startSection('header', 'Welcome to the forum'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mb-5">
        <div class="row">
            <?php echo $__env->make('layouts.custom_layout.status-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-8 mx-auto p-3 border rounded">
                <p class="text-end"><?php echo e($currentDiscussion->category->name . ' | ' . $currentDiscussion->user->username); ?></p>
                <img src="<?php echo e(asset("storage/images/$currentDiscussion->photoPath")); ?>" alt=""
                     class="w-50 mx-auto d-block mb-3">
                <h5 class="text-center"><?php echo e($currentDiscussion->title); ?></h5>
                <p class="text-center"><?php echo e($currentDiscussion->description); ?></p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-8 mx-auto p-0">
                <div class="p-3">
                    <h5>Comments:</h5>
                    <?php if(auth()->guard()->check()): ?>
                        <?php echo $__env->make('layouts.custom_layout.components.new-comment-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $currentDiscussion->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border rounded p-3 mt-2">
                        <div class="d-flex justify-content-between">
                            <small><?php echo e($comment->user->username); ?> says:</small>
                            <small><?php echo e($comment->created_at); ?></small>
                        </div>
                        <div class="d-flex">
                            <p class="m-0"><?php echo e($comment->comment); ?></p>
                            <?php if(Auth::check() && $comment->user->username == Auth::user()->username): ?>
                                <div class="ms-3">
                                    <?php echo $__env->make('layouts.custom_layout.components.edit-comment-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php echo $__env->make('layouts.custom_layout.components.delete-comment-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center">Nothing here yet! Leave comment!</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.custom_layout.components.delete-comment-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.custom_layout.components.edit-comment-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('layouts.custom_layout.components.new-comment-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.custom_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/discussion-view.blade.php ENDPATH**/ ?>