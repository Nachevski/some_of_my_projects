<i class="fa-solid fa-trash p2 btn-delete btn-delete-comment"
   data-id="<?php echo e($comment->id); ?>"
   data-bs-toggle="modal"
   data-bs-target="#deleteCommentModal"></i>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/components/delete-comment-btn.blade.php ENDPATH**/ ?>