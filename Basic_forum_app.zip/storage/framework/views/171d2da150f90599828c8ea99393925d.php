<div class="modal fade" id="newCommentModal" tabindex="-1" aria-labelledby="newCommentModal" aria-hidden="true"
     data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="newDiscussionForm">Start new discussion</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('new.comment', [$currentDiscussion->id])); ?>" method="POST"
                  id="newCommentForm">
                <?php echo csrf_field(); ?>
                <div id="validationErrors"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="comment" class="form-label w-100">Discussion description</label>
                        <textarea class="w-100" name="comment" id="comment" cols="30" rows="5"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Create New</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/new-comment-modal.blade.php ENDPATH**/ ?>