<i class="fa-solid fa-trash me-4 p2 btn-delete btn-delete-discussion"
   data-id="<?php echo e($discussion->id); ?>"
   data-bs-toggle="modal"
   data-bs-target="#deleteDiscussionModal"></i>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/components/delete-discussion-btn.blade.php ENDPATH**/ ?>