<i class="fa-regular fa-pen-to-square me-1 p2 btn-edit btn-edit-comment"
   type="button" data-id="<?php echo e($comment->id); ?>"
   data-bs-toggle="modal"
   data-bs-target="#editCommentModal"></i>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/edit-comment-btn.blade.php ENDPATH**/ ?>