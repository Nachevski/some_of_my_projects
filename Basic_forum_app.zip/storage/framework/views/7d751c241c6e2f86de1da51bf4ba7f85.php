<div class="modal fade" id="deleteCommentModal" tabindex="-1" aria-labelledby="deleteCommentModal"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="newDiscussionForm">Delete Comment?</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure?</p>
            </div>
            <form action="" method="POST" id="deleteCommentForm">
                <?php echo csrf_field(); ?>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger">Delete</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/delete-comment-modal.blade.php ENDPATH**/ ?>