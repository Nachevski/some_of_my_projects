<footer>
<div class="container-fluid">
    <div class="row">
        <div class="col-8 mx-auto p-3">
            <p class="text-center m-0">FOOTER TEST</p>
        </div>
    </div>
</div>
</footer>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/footer.blade.php ENDPATH**/ ?>