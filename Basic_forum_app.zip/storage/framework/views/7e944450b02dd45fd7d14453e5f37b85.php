<?php $__env->startSection('header', 'Welcome to the forum'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('layouts.custom_layout.components.new-discussion-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(Auth::user()->role == 'Admin'): ?>
            <?php echo $__env->make('layouts.custom_layout.components.approve-discussions-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    <?php else: ?>
        <p class="text-center">Please login to create new discussion!</p>
    <?php endif; ?>

    <div class="container-fluid mt-3">
        <div class="row">
            <?php echo $__env->make('layouts.custom_layout.status-messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__empty_1 = true; $__currentLoopData = $discussions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discussion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('view.discussion', [$discussion->id])); ?>"
                   class="text-light text-decoration-none mb-2">
                    <div class="discussion col-8 mx-auto p-3 border rounded">
                        <div class="row align-items-center">
                            <div class="col-8">
                                <div class="row align-items-center">
                                    <div class="col-3">
                                        <img
                                            src="<?php echo e(asset("storage/images/$discussion->photoPath")); ?>"
                                            alt="" class="w-100">
                                    </div>
                                    <div class="col">
                                        <h5><?php echo e($discussion->title); ?></h5>
                                        <p class="mb-0"><?php echo e($discussion->description); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4 d-flex align-items-center justify-content-end ">
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->role == 'Admin'): ?>
                                        <?php if($discussion->is_approved == 0): ?>
                                            <form action="<?php echo e(route('discussion.approve', [$discussion->id])); ?>"
                                                  method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-link p-0">
                                                    <i class="fa-solid fa-circle-check me-3 p2 text-success">
                                                    </i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php if($discussion->user->username == Auth::user()->username || Auth::user()->role == 'Admin'): ?>
                                        <?php echo $__env->make('layouts.custom_layout.components.edit-discussion-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('layouts.custom_layout.components.delete-discussion-btn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <p class="text-center m-0"><?php echo e($discussion->category->name); ?>

                                    | <?php echo e($discussion->user->username); ?></p>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-center">Nothing here yet! Start a topic!</p>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $__env->make('layouts.custom_layout.components.delete-discussion-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.custom_layout.components.edit-discussion-model', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make('layouts.custom_layout.components.new-discussion-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.custom_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/homepage.blade.php ENDPATH**/ ?>