<div class="modal fade" id="editCommentModal" tabindex="-1" aria-labelledby="editCommentModal"
     aria-hidden="true"
     data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Edit comment</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="POST" id="editCommentForm">
                <?php echo csrf_field(); ?>
                <div id="validationErrors"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="comment" class="form-label w-100">Comment</label>
                        <textarea class="w-100" name="comment" id="commentArea" cols="30" rows="5"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/edit-comment-modal.blade.php ENDPATH**/ ?>