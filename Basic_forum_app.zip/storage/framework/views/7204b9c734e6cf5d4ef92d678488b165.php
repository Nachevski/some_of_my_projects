<div class="modal fade" id="newDiscussionModal" tabindex="-1" aria-labelledby="newDiscussionModal" aria-hidden="true"
     data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Start new discussion</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="<?php echo e(route('new.discussion')); ?>" method="POST" enctype="multipart/form-data"
                  id="newDiscussionForm">
                <?php echo csrf_field(); ?>
                <div class="validationErrors"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Discussion title</label>
                        <input type="text" class="form-control" id="title" name="title">
                    </div>

                    <div class="mb-3">
                        <label for="photo" class="form-label">Upload photo</label>
                        <input class="form-control" type="file" id="photo" name="photo">
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label w-100">Discussion description</label>
                        <textarea class="w-100" name="description" id="description" cols="30" rows="5"></textarea>
                    </div>

                    <div class="mb-3">
                        <select class="form-select" name="category_id">
                            <option selected>Please select category</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Create New</button>

                </div>
            </form>

        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/components/new-discussion-modal.blade.php ENDPATH**/ ?>