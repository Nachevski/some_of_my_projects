<nav class="navbar navbar-expand-lg navbar-dark bg-dark border-bottom">
    <div class="container-md">
        <a class="navbar-brand" href="/">Laravel</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse flex-grow-0" id="navbarNavDropdown">
            <?php if(auth()->guard()->check()): ?>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userOptions" role="button"
                           data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(Auth::user()->username); ?>

                        </a>
                        <ul class="dropdown-menu" aria-labelledby="userOptions">
                            <?php if(Auth::user()->role == 'Admin'): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('approve.discussions')); ?>">Approve
                                        discussions</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log Out</a></li>
                        </ul>
                    </li>
                </ul>
            <?php else: ?>
                <a href="/login" class="nav-link me-2 text-light">Login</a>
                <a href="/register" class="nav-link text-light">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/navbar.blade.php ENDPATH**/ ?>