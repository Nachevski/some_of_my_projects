<div class="container-fluid">
    <div class="row">
        <div class="col-8 mx-auto">
            <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#newDiscussionModal">Start new
                discussion
            </button>
        </div>
    </div>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/components/new-discussion-btn.blade.php ENDPATH**/ ?>