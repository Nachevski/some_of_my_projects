<div class="container-fluid">
    <div class="row p-5">
        <div class="col-8 mx-auto text-center">
            <h1><?php echo $__env->yieldContent('header'); ?></h1>
        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_25/Challenge_25/resources/views/layouts/custom_layout/header.blade.php ENDPATH**/ ?>