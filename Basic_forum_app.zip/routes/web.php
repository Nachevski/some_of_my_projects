<?php

use App\Http\Controllers\CommentController;
use App\Http\Controllers\DiscussionController;
use App\Http\Controllers\HomePageControler;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//PUBLIC
Route::get('/', [HomePageControler::class, 'index'])->name('homePage');
Route::get('/discussion/{id}', [DiscussionController::class, 'show'])->name('view.discussion');

//CUSTOM MIDDLEWARE
Route::get('/discussions', [DiscussionController::class, 'index'])->name('approve.discussions')->middleware('admin.access');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/get-discussion/{id}', [DiscussionController::class, 'edit']);
    Route::get('/get-comment/{id}', [CommentController::class, 'edit']);

    //DISCUSSIONS
    Route::post('/discussion/validate', [DiscussionController::class, 'checkData']);
    Route::post('/discussion/new', [DiscussionController::class, 'store'])->name('new.discussion');
    Route::post('/discussion/approve/{id}', [DiscussionController::class, 'approve'])->name('discussion.approve');
    Route::post('/discussion/delete/{id}', [DiscussionController::class, 'destroy'])->name('discussion.delete');

    //COMMENTS
    Route::post('/comment/validate', [CommentController::class, 'checkData']);
    Route::post('/discussion/{id}/new-comment', [CommentController::class, 'store'])->name('new.comment');
    Route::post('/update-comment/{id}', [CommentController::class, 'update']);
    Route::post('/update-discussion/{id}', [DiscussionController::class, 'update']);
    Route::post('/delete-comment/{id}', [CommentController::class, 'destroy']);
});


require __DIR__ . '/auth.php';
