@extends('layouts.custom_layout.app')

@section('header', 'Approve discussions')

@section('content')

    <div class="container-fluid mt-3">
        <div class="row">
            @include('layouts.custom_layout.status-messages')

            @forelse($discussions as $discussion)
                @if($discussion->is_approved == 0)
                    <a href="{{route('view.discussion', [$discussion->id])}}"
                       class="text-light text-decoration-none mb-2">
                        <div class="discussion col-8 mx-auto p-3 border rounded">
                            <div class="row align-items-center">
                                <div class="col-8">
                                    <div class="row align-items-center">
                                        <div class="col-3">
                                            <img
                                                src="{{asset("storage/images/$discussion->photoPath")}}"
                                                alt="" class="w-100">
                                        </div>
                                        <div class="col">
                                            <h5>{{$discussion->title}}</h5>
                                            <p class="mb-0">{{$discussion->description}}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-4 d-flex align-items-center justify-content-end ">
                                    <form action="{{route('discussion.approve', [$discussion->id])}}"
                                          method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-link p-0">
                                            <i class="fa-solid fa-circle-check me-3 p2 text-success">
                                            </i>
                                        </button>
                                    </form>
                                    @include('layouts.custom_layout.components.edit-discussion-btn')
                                    @include('layouts.custom_layout.components.delete-discussion-btn')
                                    <p class="text-center m-0">{{$discussion->category->name}}
                                        | {{$discussion->user->username}}</p>
                                </div>
                            </div>
                        </div>
                    </a>
                @endif
            @empty
                <p class="text-center">Nothing new for approving right now!!</p>
            @endforelse
        </div>
    </div>

    @include('layouts.custom_layout.components.delete-discussion-modal')
    @include('layouts.custom_layout.components.edit-discussion-model')

@endsection
