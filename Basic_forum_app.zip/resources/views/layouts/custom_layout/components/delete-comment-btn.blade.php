<i class="fa-solid fa-trash p2 btn-delete btn-delete-comment"
   data-id="{{$comment->id}}"
   data-bs-toggle="modal"
   data-bs-target="#deleteCommentModal"></i>
