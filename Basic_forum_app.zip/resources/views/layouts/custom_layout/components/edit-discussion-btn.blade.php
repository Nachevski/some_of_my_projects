<i class="fa-regular fa-pen-to-square me-3 p2 btn-edit btn-edit-discussion"
   data-id="{{$discussion->id}}"
   data-bs-toggle="modal"
   data-bs-target="#editDiscussionModal"></i>
