<div class="modal fade" id="newDiscussionModal" tabindex="-1" aria-labelledby="newDiscussionModal" aria-hidden="true"
     data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Start new discussion</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="{{route('new.discussion')}}" method="POST" enctype="multipart/form-data"
                  id="newDiscussionForm">
                @csrf
                <div class="validationErrors"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Discussion title</label>
                        <input type="text" class="form-control" id="title" name="title">
                    </div>

                    <div class="mb-3">
                        <label for="photo" class="form-label">Upload photo</label>
                        <input class="form-control" type="file" id="photo" name="photo">
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label w-100">Discussion description</label>
                        <textarea class="w-100" name="description" id="description" cols="30" rows="5"></textarea>
                    </div>

                    <div class="mb-3">
                        <select class="form-select" name="category_id">
                            <option selected>Please select category</option>
                            @foreach($categories as $category)
                                <option value="{{$category->id}}">{{$category->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Create New</button>

                </div>
            </form>

        </div>
    </div>
</div>
