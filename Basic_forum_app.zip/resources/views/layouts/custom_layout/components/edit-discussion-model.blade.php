<div class="modal fade" id="editDiscussionModal" tabindex="-1" aria-labelledby="editDiscussionModal"
     aria-hidden="true"
     data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Start new discussion</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <form action="" method="POST" enctype="multipart/form-data"
                  id="editDiscussionForm">
                @csrf
                <div class="validationErrors"></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Discussion title</label>
                        <input type="text" class="form-control" id="discussionTitle" name="title">
                    </div>

                    <div class="mb-3">
                        <label for="photo" class="form-label">Upload photo</label>
                        <input class="form-control" type="file" id="photo" name="photo">
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label w-100">Discussion description</label>
                        <textarea class="w-100" name="description" id="discussionDescription" cols="30"
                                  rows="5"></textarea>
                    </div>

                    <div class="mb-3">
                        <select class="form-select" name="category_id" id="discussionCategories">
                            @foreach($categories as $category)
                                <option value="{{$category->id}}">{{$category->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
