<i class="fa-regular fa-pen-to-square me-1 p2 btn-edit btn-edit-comment"
   type="button" data-id="{{$comment->id}}"
   data-bs-toggle="modal"
   data-bs-target="#editCommentModal"></i>
