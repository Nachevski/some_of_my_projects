<div class="container-fluid mt-3">
    <div class="row">
        <div class="col-8 mx-auto">
            <a href="{{route('approve.discussions')}}" class="btn btn-primary">Approve
                discussions
            </a>
        </div>
    </div>
</div>
