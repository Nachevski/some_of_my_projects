<i class="fa-solid fa-trash me-4 p2 btn-delete btn-delete-discussion"
   data-id="{{$discussion->id}}"
   data-bs-toggle="modal"
   data-bs-target="#deleteDiscussionModal"></i>
