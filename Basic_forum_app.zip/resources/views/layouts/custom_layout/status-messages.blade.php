@if(Session::has('successStatus'))
    <div class="col-8 mx-auto">
        <div class="alert alert-success text-center" role="alert">
            {{ Session::get('successStatus') }}
        </div>
    </div>
@endif

@if ($errors->all())
    <ul class="alert alert-danger" role="alert">
        <div class="ps-5">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    </ul>
@endif
