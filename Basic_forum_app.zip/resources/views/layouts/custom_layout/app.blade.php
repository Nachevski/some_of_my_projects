<!doctype html>
<html lang="en" data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    @include('layouts.custom_layout.styles')
    <title>Challenge_25</title>
</head>
<body>
@include('layouts.custom_layout.navbar')
@include('layouts.custom_layout.header')

@yield('content')

@include('layouts.custom_layout.scripts')
</body>
</html>
