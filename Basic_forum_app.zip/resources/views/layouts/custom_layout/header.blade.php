<div class="container-fluid">
    <div class="row p-5">
        <div class="col-8 mx-auto text-center">
            <h1>@yield('header')</h1>
        </div>
    </div>
</div>
