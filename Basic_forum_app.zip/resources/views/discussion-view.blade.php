@extends('layouts.custom_layout.app')

@section('header', 'Welcome to the forum')

@section('content')
    <div class="container-fluid mb-5">
        <div class="row">
            @include('layouts.custom_layout.status-messages')
            <div class="col-8 mx-auto p-3 border rounded">
                <p class="text-end">{{$currentDiscussion->category->name . ' | ' . $currentDiscussion->user->username}}</p>
                <img src="{{asset("storage/images/$currentDiscussion->photoPath")}}" alt=""
                     class="w-50 mx-auto d-block mb-3">
                <h5 class="text-center">{{$currentDiscussion->title}}</h5>
                <p class="text-center">{{$currentDiscussion->description}}</p>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-8 mx-auto p-0">
                <div class="p-3">
                    <h5>Comments:</h5>
                    @Auth
                        @include('layouts.custom_layout.components.new-comment-btn')
                    @endauth
                </div>
                @forelse($currentDiscussion->comments as $comment)
                    <div class="border rounded p-3 mt-2">
                        <div class="d-flex justify-content-between">
                            <small>{{$comment->user->username}} says:</small>
                            <small>{{$comment->created_at}}</small>
                        </div>
                        <div class="d-flex">
                            <p class="m-0">{{$comment->comment}}</p>
                            @if(Auth::check() && $comment->user->username == Auth::user()->username)
                                <div class="ms-3">
                                    @include('layouts.custom_layout.components.edit-comment-btn')
                                    @include('layouts.custom_layout.components.delete-comment-btn')
                                </div>
                            @endif
                        </div>
                    </div>
                @empty
                    <p class="text-center">Nothing here yet! Leave comment!</p>
                @endforelse
            </div>
        </div>
    </div>

    @include('layouts.custom_layout.components.delete-comment-modal')
    @include('layouts.custom_layout.components.edit-comment-modal')

    @Auth
        @include('layouts.custom_layout.components.new-comment-modal')
    @endauth

@endsection
