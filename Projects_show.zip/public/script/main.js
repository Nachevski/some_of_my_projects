$(document).ready(function () {
    //GENERATED @CSRF TOKEN FOR POSTING DATA
    const CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
    //***************************************
    //CHANGE IF YOU USE DIFFERENT SERVER CONF
    const LOCALHOST = 'http://127.0.0.1';
    const PORT = '8000';
    const GET_PROJECT_API = 'api/project'
    const VALIDATE_EMPLOYEE_API = 'employee/validate'
    //***************************************

    let hasOpenedForm = false;

    $('.btn-edit').on('click', function (e) {
        let projectID = $(this).data('id')
        const currentElement = $(this)
        if (!hasOpenedForm) {
            hasOpenedForm = true
            //API CALL
            $.get(`${LOCALHOST}:${PORT}/${GET_PROJECT_API}/${projectID}`, function (data) {
                let editForm = `
                    <form action="/project/update/${projectID}" method="POST" class="p-3 border rounded">
                        <input type="hidden" name="_token" value="${CSRF_TOKEN}" />
                        <div class="mb-1">
                            <label for="title" class="form-label">Наслов</label>
                            <input type="text" class="form-control" id="title" name="title"
                            value="${data.data.title}">
                        </div>
                        <div class="mb-1">
                            <label for="subtitle" class="form-label">Поднаслов</label>
                            <input type="text" class="form-control" id="subtitle" name="subtitle"
                            value="${data.data.subtitle}">
                        </div>
                        <div class="mb-1">
                            <label for="description" class="form-label">Опис</label>
                            <textarea id="description" name="description" cols="50" rows="5"
                            class="form-control w-100">${data.data.description}</textarea>
                        </div>
                        <div class="mb-1">
                            <label for="imageUrl" class="form-label">Урл до сликата</label>
                            <input type="text" class="form-control" id="imageUrl" name="imageUrl"
                            value="${data.data.imageUrl}">
                        </div>
                        <div class="mb-3">
                            <label for="linkUrl" class="form-label">Урл до проектот</label>
                            <input type="text" class="form-control" id="linkUrl" name="linkUrl"
                            value="${data.data.linkUrl}">
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-success me-3">Зачувај</button>
                            <div class="btn btn-warning btn-cancel">Откажи</div>
                        </div>
                    </form>`;

                currentElement.closest('.card-container').append(editForm)
                currentElement.closest('.card').addClass('hide');

                $('.btn-cancel').on('click', function (e) {
                    $(this).closest('.card-container').children('.card').removeClass('hide');
                    $(this).closest('.card-container').children().last().remove()
                    hasOpenedForm = false
                })
            })
        } else {
            alert('Затворете или снимете ја претходната форма за да едитирате друг проект!')
        }
    })


    $('#employeeForm').submit(function (e) {
        e.preventDefault()
        $('#validationErrors').empty()
        const formData = $('#employeeForm');
        let errors = ''
        //VALIDATE API CALL
        $.post(`${LOCALHOST}:${PORT}/${VALIDATE_EMPLOYEE_API}`, formData.serialize(), function (data) {
            if (!data.success) {
                const result = Object.values(data.errors);
                result.forEach((element) => {
                    errors += `<li>${element[0]}</li>`
                })
                let child = `
                        <ul class="alert alert-danger" role="alert" id="errors">
                            <div class="ps-5">
                            ${errors}
                            </div>
                        </ul>`
                $('#validationErrors').append(child)
                return false
            }
            formData.unbind('submit').submit()
        }, 'json')
    })
})


