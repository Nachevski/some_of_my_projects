<div class="col-12 col-md-10 offset-md-1 col-lg-8 offset-lg-2 d-flex">
    <div class="w-100">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a href="<?php echo e(route('adminPanel.new')); ?>" class="nav-link <?php if(Request::is('projects/new')): ?> active <?php endif; ?>"
                   type="button">Додај
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('adminPanel.modify')); ?>"
                   class="nav-link <?php if(Request::is('projects/modify')): ?> active <?php endif; ?>"
                   type="button">Измени
                </a>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/layout/admin/menu-select.blade.php ENDPATH**/ ?>