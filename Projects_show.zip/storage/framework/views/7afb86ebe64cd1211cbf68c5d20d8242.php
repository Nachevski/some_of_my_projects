<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
<?php /**PATH /home/nachevski/Desktop/Challenge_24/Challenge_24/resources/views/layout/styles.blade.php ENDPATH**/ ?>