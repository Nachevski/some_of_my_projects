<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">
        <div class="row mb-5">
            <?php echo $__env->make('layout.admin.menu-select', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if(Request::is('projects/new')): ?>
                <?php echo $__env->make('layout.admin.add-new-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('layout.admin.modify-projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/admin-panel.blade.php ENDPATH**/ ?>