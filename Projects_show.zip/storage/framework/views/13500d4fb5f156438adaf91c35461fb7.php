<div class="container-fluid bg-warning">
    <div class="row">
        <div class="col-8 offset-2">

            <nav class="navbar navbar-expand-lg">
                <div class="container-fluid">
                    <a class="navbar-brand text-center" href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(asset('images/logo_footer_black.png')); ?>" alt="" width="50px">
                        <h6>BRAINSTER</h6>
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse flex-grow-0" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0 text-center align-items-center">
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="#" target="_blank">Академија за
                                    Програмирање</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="#" target="_blank">Академија за
                                    Маркетинг</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="#" target="_blank">Академија за
                                    Дизајн</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="#" target="_blank">Блог</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#" target="_blank">Вработи наши
                                    студенти</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>

        </div>
    </div>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_24/Challenge_24/resources/views/layout/navbar.blade.php ENDPATH**/ ?>