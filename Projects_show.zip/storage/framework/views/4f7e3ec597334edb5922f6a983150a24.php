<div class="actions hide p-3 bg-light">
    <button class="custom-btn btn-delete ps-4 pe-4 pt-2 pb-2 me-3 border rounded"
            data-bs-toggle="modal"
            data-bs-target="#exampleModal<?php echo e($project->id); ?>">
        <i class="fa-solid fa-x h4 mb-0"></i>
    </button>
    <button class="custom-btn btn-edit ps-4 pe-4 pt-2 pb-2 border rounded">
        <i class="fa-solid fa-pen-to-square h4 mb-0"></i>
    </button>
</div>

<div class="modal fade" id="exampleModal<?php echo e($project->id); ?>" tabindex="-1"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Избриши</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Далис те сигурни дека сакате да го избришете
                    проектот: <?php echo e($project->title); ?>?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                    Откажи
                </button>
                <form action="<?php echo e(route('delete.project', $project->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="projectID" value="{{}}" hidden>
                    <button type="submit" class="btn btn-danger">Избриши</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/layout/admin/modify-options.blade.php ENDPATH**/ ?>
