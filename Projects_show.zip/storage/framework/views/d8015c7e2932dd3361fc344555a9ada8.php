[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>