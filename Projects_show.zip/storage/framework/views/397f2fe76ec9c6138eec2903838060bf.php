<div class="col-8 offset-2 d-flex">
    <div class="w-100">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link " id="newProject-tab" data-bs-toggle="tab"
                        data-bs-target="#addNew"
                        type="button" role="tab" aria-controls="home" aria-selected="true">Додај
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="modifyProject-tab" data-bs-toggle="tab"
                        data-bs-target="#projects"
                        type="button" role="tab" aria-controls="projects" aria-selected="true">Измени
                </button>
            </li>
        </ul>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/layout/admin/menu-select.blade.php ENDPATH**/ ?>
