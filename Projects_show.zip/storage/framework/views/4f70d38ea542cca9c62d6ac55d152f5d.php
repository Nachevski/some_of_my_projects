<?php echo e($slot); ?>

<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>