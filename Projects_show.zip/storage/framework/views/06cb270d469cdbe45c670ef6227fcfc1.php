<?php $__env->startSection('content'); ?>
    
    <div class="container-fluid mt-4">
        <div class="row mb-5">
            <div class="col-8 offset-2 d-flex flex-wrap">

                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-container ">
                        <a href="<?php echo e($project->linkUrl); ?>" class="text-decoration-none">
                            <div class="card m-2">
                                <img src="<?php echo e($project->imageUrl); ?>" class="card-img-top ps-5 pe-5 pb-2 pt-2" alt="...">
                                <div class="card-body">
                                    <h4 class="card-title"><?php echo e($project->title); ?></h4>
                                    <h5 class="card-title"><?php echo e($project->subtitle); ?></h5>
                                    <p class="card-text"><?php echo e($project->description); ?></p>
                                </div>
                            </div>
                        </a>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_24/Challenge_24/resources/views/home.blade.php ENDPATH**/ ?>