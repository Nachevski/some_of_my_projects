<div id="projects" class="col-12 col-lg-10 col-xl-8 mx-auto pt-3 pb-3">
    <h3>Измени поостоечки проекти:</h3>
    <?php echo $__env->make('layout.statusMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="d-flex flex-wrap">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-container col-12 col-md-6 col-lg-4 p-3">
                <div class="card h-100">
                    <div class="card-inner h-100 d-flex flex-wrap align-content-between text-center">
                        <a href="<?php echo e($project->linkUrl); ?>" class="text-decoration-none">
                            <img src="<?php echo e($project->imageUrl); ?>" class="card-img-top ps-5 pe-5 pb-2 pt-2" alt="...">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e($project->title); ?></h4>
                                <p class="card-title text-muted mb-3"><?php echo e($project->subtitle); ?></p>
                                <p class="card-text"><?php echo e($project->description); ?></p>
                            </div>
                        </a>
                        <?php echo $__env->make('layout.admin.modify-options', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/layout/admin/modify-projects.blade.php ENDPATH**/ ?>