<footer>
    <div class="container-fluid bg-light">
        <div class="row">
            <div class="col-6 offset-3 d-flex align-items-center justify-content-center p-3">
                <div class="me-3">
                    <p class="m-0">Made with <span class="text-danger h3">&hearts;</span> by:</p>
                </div>
                <div class="me-3 text-center">
                    <img src="<?php echo e(asset('images/logo_footer_black.png')); ?>" alt="" width="50px">
                    <h6>BRAINSTER</h6>
                </div>
                <div class="d-flex">
                    <p class="m-0 me-3">-</p>
                    <a href="https://brainster.co" class="text-decoration-none text-success me-3" target="_blank">Say Hi!</a>
                    <p class="m-0">- Terms</p>
                </div>
            </div>
        </div>
    </div>

</footer>
<?php /**PATH /home/nachevski/Desktop/Challenge_24/Challenge_24/resources/views/layout/footer.blade.php ENDPATH**/ ?>