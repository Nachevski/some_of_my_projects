<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-4">
        <div class="row mb-5">
            <div id="projects"
                 class="col-12 col-lg-10 col-xl-8 mx-auto d-flex flex-wrap fade active show">
                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-container col-12 col-md-6 col-lg-4 p-3">
                        <div class="card h-100">
                            <a href="<?php echo e($project->linkUrl); ?>" class="text-decoration-none">
                                <img src="<?php echo e($project->imageUrl); ?>" class="card-img-top ps-5 pe-5 pb-2 pt-2" alt="...">
                                <div class="card-body">
                                    <h4 class="card-title"><?php echo e($project->title); ?></h4>
                                    <p class="card-title text-muted mb-3"><?php echo e($project->subtitle); ?></p>
                                    <p class="card-text"><?php echo e($project->description); ?></p>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/home.blade.php ENDPATH**/ ?>