<?php if(Session::has('successStatus')): ?>
    <div class="alert alert-success text-center" role="alert">
        <?php echo e(Session::get('successStatus')); ?>

    </div>
<?php endif; ?>

<?php if($errors->all()): ?>
    <ul class="alert alert-danger" role="alert">
        <div class="ps-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </ul>
<?php endif; ?>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/layout/admin/statusMessages.blade.php ENDPATH**/ ?>