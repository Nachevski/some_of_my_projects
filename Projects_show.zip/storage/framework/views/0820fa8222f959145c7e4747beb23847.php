<div>
    <div class="mail-container" style="padding: 30px">
        <div class="logo" style="width:100px; margin: 0 auto">
            <img src="https://project-brainsterlabs.netlify.app/images/Logo.png" alt=""
                 style="display: block; width:100px; margin: 0 auto">
        </div>
        <div class="content" style="padding: 30px">
            <h3 style="margin-bottom: 30px; text-align: center; ">Вашето барање за вработување наши студенти е
                примено!</h3>
            <div style="background-color: #ffe300; padding: 15px; margin: 0 auto">
                <h3>Контакт емајл: <?php echo e($newEmployee->email); ?></h3>
                <h3>Број за контакт: <?php echo e($newEmployee->phone); ?></h3>
                <h3>Има на компанија: <?php echo e($newEmployee->company); ?></h3>
            </div>
            <div style="margin-top: 30px">
                <h3 style="margin-bottom: 30px; text-align: center; ">Ви благодариме!</h3>
                <a href="https://brainster.co/"
                   style=" display: block; width: fit-content;
               margin: 0 auto;
               padding: 10px 20px;
               border: 1px solid black;
               border-radius: 5px;
               text-decoration: none;
               color: black;
               background-color: #ffe300;"
                   target="_blank">Brainster</a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/emails/employee/confirmation-email.blade.php ENDPATH**/ ?>