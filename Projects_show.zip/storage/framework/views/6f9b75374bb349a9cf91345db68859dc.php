<?php if (Session::has('successStatus')): ?>
    <div class="alert alert-success text-center" role="alert">
        <?php echo e(Session::get('successStatus')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/nachevski/Desktop/Challenge_24 O/Challenge_24/resources/views/layout/statusMessages.blade.php ENDPATH**/ ?>
