<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\MailController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ProjectController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/', [PageController::class, 'index'])->name('home');
Route::get('/logout', [AuthenticatedSessionController::class, 'destroy']);
Route::get('/projects/modify', [PageController::class, 'adminPanel'])->name('adminPanel.modify');
Route::get('/projects/new', [PageController::class, 'adminPanel'])->name('adminPanel.new');
// MAIL
Route::get('/send-mail', [MailController::class, 'sendMail'])->name('send.mail');

Route::post('/project/new', [ProjectController::class, 'store'])->name('new.project');
Route::post('/project/update/{projectID}', [ProjectController::class, 'update']);
Route::post('/employee/new', [EmployeeController::class, 'store'])->name('new.employee');
Route::post('/employee/validate', [EmployeeController::class, 'checkData']);

Route::delete('/project/delete/{projectID}', [ProjectController::class, 'destroy'])->name('delete.project');


//Route::get('/', PageController::class, 'show');
//Route::get('/dashboard', function () {
//    return view('dashboard');
//    return view('dashboard');
//})->middleware(['auth', 'verified'])->name('dashboard');

//Route::middleware('auth')->group(function () {
//    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
//    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
//    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
//});

require __DIR__ . '/auth.php';
