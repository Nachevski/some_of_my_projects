<?php

namespace App\Http\Controllers;

use App\Http\Requests\EmployeeRequest;
use App\Mail\ConfirmationMail;
use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class EmployeeController extends Controller
{
    public function store(EmployeeRequest $request)
    {
        Employee::create(
            $request->all()
        );
        Mail::to($request['email'])->send(new ConfirmationMail($request));

        return redirect('/')->with('successStatus', 'Ви благодариме на интересот! Конфирмација е испратена на вашиот емаил!');
    }

    public function checkData(EmployeeRequest $request)
    {
        if (isset($request)) {
            return response()->json(['success' => 'true'], 200);
        }
    }

}
