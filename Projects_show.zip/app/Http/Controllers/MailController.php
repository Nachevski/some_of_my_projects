<?php

namespace App\Http\Controllers;

use App\Http\Requests\EmployeeRequest;
use App\Mail\ConfirmationMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
    //
    public function sendMail(EmployeeRequest $request)
    {
        Mail::to($request['email'])->send(new ConfirmationMail($request));
    }
}
