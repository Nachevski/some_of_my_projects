<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProjectRequest;
use App\Http\Resources\ProjectResource;
use App\Models\Project;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $books = Project::paginate();
        return ProjectResource::collection($books);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     * @param ProjectRequest $request
     */
    public function store(ProjectRequest $request)
    {
        Project::create(
            $request->all()
        );
        return redirect('/projects/new')->with('successStatus', 'Продуктот "' . $request['title'] . '" е успешно додаден!');

    }

    /**
     * Display the specified resource.
     */
    public function show(Project $project)
    {
        return new ProjectResource($project);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ProjectRequest $request, Project $projectID)
    {
        $projectID->update($request->all());
        return redirect('projects/modify')->with('successStatus', "Проектот е успешно апдејтиран.");
    }

    /**
     * Remove the specified resource from storage.
     * @param Project $projectID
     */
    public function destroy(Project $projectID)
    {
        $projectID->delete();
        return redirect('/projects/modify')->with('successStatus', 'Проектот "' . $projectID->title . '" е успешно избришан!');
    }


    public static function getAllProjects()
    {
        return Project::all();
    }
}
