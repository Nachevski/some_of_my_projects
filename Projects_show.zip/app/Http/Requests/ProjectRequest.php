<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class ProjectRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return Auth::check();
    }

    public function messages()
    {
        return [
            'title.required' => 'Насловот е задолжителен!',
            'subtitle.required' => 'Поднасловот е задолжителен!',
            'description.required' => 'Описот е задолжителен!',
            'description.max' => 'Описот не смее да има повеќе од 200 букви!',
            'linkUrl.required' => 'Линк до проектот е задолжителен!',
            'linkUrl.url' => 'Линкот до проектот не е валиден!',
            'imageUrl.required' => 'Линк до сликата е задолжителен!',
            'imageUrl.url' => 'Линкот до сликата не е валиден!',
        ];
    }

    /**
     * Get the validation rules that apply to the request.
     *
     */
    public function rules(): array
    {
        return [
            'title' => 'required',
            'subtitle' => 'required',
            'description' => 'required | max:200',
            'linkUrl' => 'required | url',
            'imageUrl' => 'required | url',
        ];
    }
}
