@extends('layout.master')

@section('content')
    <div class="container-fluid mt-4">
        <div class="row mb-5">
            @include('layout.admin.menu-select')

            @if(Request::is('projects/new'))
                @include('layout.admin.add-new-form')
            @else
                @include('layout.admin.modify-projects')
            @endif

        </div>
    </div>
@endsection
