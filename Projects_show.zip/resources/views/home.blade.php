@extends('layout.master')

@section('content')
    <div class="container-fluid mt-4">
        <div class="row mb-5">
            <div id="projects"
                 class="col-12 col-lg-10 col-xl-8 mx-auto d-flex flex-wrap fade active show">
                @foreach($projects as $project)
                    <div class="card-container col-12 col-md-6 col-lg-4 p-3">
                        <div class="card h-100">
                            <a href="{{$project->linkUrl}}" class="text-decoration-none">
                                <img src="{{$project->imageUrl}}" class="card-img-top ps-5 pe-5 pb-2 pt-2" alt="...">
                                <div class="card-body">
                                    <h4 class="card-title">{{$project->title}}</h4>
                                    <p class="card-title text-muted mb-3">{{$project->subtitle}}</p>
                                    <p class="card-text">{{$project->description}}</p>
                                </div>
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
