<div id="new-project-form" class="col-12 col-md-10 col-lg-8 mx-auto p-4">
    <h3>Додај нов проекти:</h3>
    <div class="row">
        <div class="mx-auto col-10 col-lg-6">
            @include('layout.statusMessages')
            <form action="{{route('new.project')}}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="title" class="form-label">Наслов</label>
                    <input type="text" class="form-control" id="title" name="title" value="{{old('title')}}">
                </div>

                <div class="mb-3">
                    <label for="subtitle" class="form-label">Поднаслов</label>
                    <input type="text" class="form-control" id="subtitle" name="subtitle" value="{{old('subtitle')}}">
                </div>

                <div class="mb-3">
                    <label for="description" class="form-label">Опис</label>
                    <textarea id="description" name="description" cols="50" rows="5"
                              class="form-control w-100">{{old('description')}}</textarea>
                </div>

                <div class="mb-3">
                    <label for="imageUrl" class="form-label">Урл до сликата</label>
                    <input type="text" class="form-control" id="imageUrl" name="imageUrl" placeholder="http://"
                           value="{{old('imageUrl')}}">
                </div>

                <div class="mb-3">
                    <label for="linkUrl" class="form-label">Урл до проектот</label>
                    <input type="text" class="form-control" id="linkUrl" name="linkUrl" placeholder="http://"
                           value="{{old('linkUrl')}}">
                </div>

                <button type="submit" class="btn btn-warning w-100">Додај</button>
            </form>
        </div>
    </div>
</div>
