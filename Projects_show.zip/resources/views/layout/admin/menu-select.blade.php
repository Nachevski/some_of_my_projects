<div class="col-12 col-md-10 offset-md-1 col-lg-8 offset-lg-2 d-flex">
    <div class="w-100">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item">
                <a href="{{route('adminPanel.new')}}" class="nav-link @if(Request::is('projects/new')) active @endif"
                   type="button">Додај
                </a>
            </li>
            <li class="nav-item">
                <a href="{{route('adminPanel.modify')}}"
                   class="nav-link @if(Request::is('projects/modify')) active @endif"
                   type="button">Измени
                </a>
            </li>
        </ul>
    </div>
</div>
