<div class="container-fluid bg-warning">
    <div class="row">
        <div class="col-12 col-lg-8 offset-lg-2">
            <nav class="navbar navbar-expand-md">
                <div class="container-fluid">
                    <a class="navbar-brand text-center flex-grow-1 flex--lg-grow-0 me-0 me-lg-4"
                       href="{{route('home')}}">
                        <img src="{{asset('images/logo_footer_black.png')}}" alt="" width="50px">
                        <h6>BRAINSTER</h6>
                    </a>
                    <button class="navbar-toggler position-absolute end-0" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse flex-grow-0" id="navbarSupportedContent">
                        <ul class="navbar-nav me-auto mb-2 mb-lg-0 text-lg-center align-items-lg-center">
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="https://brainster.co/full-stack/"
                                   target="_blank">Академија за
                                    Програмирање</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="https://brainster.co/marketing/"
                                   target="_blank">Академија за
                                    Маркетинг</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="https://brainster.co/ux-ui-design/"
                                   target="_blank">Академија за
                                    Дизајн</a>
                            </li>
                            <li class="nav-item me-2">
                                <a class="nav-link active" aria-current="page" href="https://blog.brainster.co/"
                                   target="_blank">Блог</a>
                            </li>

                            <li class="nav-item">
                                <a type="button" class="nav-link active" data-bs-toggle="modal"
                                   data-bs-target="#employeeModal">
                                    Вработи наши студенти
                                </a>
                            </li>

                            @auth
                                <div class="dropdown">
                                    <button class="btn btn-dark dropdown-toggle w-100" type="button"
                                            id="dropdownMenu" data-bs-toggle="dropdown" aria-expanded="false">
                                        Здраво, {{Auth::user()->name}}
                                    </button>
                                    <ul class="dropdown-menu text-center" aria-labelledby="dropdownMenu">
                                        <li><a class="dropdown-item p-2" href="{{route('adminPanel.modify')}}">Измени
                                                проекти</a></li>
                                        <li><a class="dropdown-item p-2" href="{{route('adminPanel.new')}}">Додај
                                                нов</a></li>
                                        <hr>
                                        <li><a class="dropdown-item text-danger p-2" href="/logout">Одјави се</a></li>
                                    </ul>
                                </div>
                            @else
                                <a href="/login" class="btn btn-success">Логирај се</a>
                            @endauth

                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>

