<header class="d-flex justify-content-center align-items-center flex-column text-light">
    <h1>Brainster.xyz Labs</h1>
    <h3>Проекти од академиите на Brainster</h3>
</header>
