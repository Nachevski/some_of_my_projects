<footer>
    <div class="container-fluid bg-light">
        <div class="row">
            <div class="col-10 col-lg-6 mx-auto d-flex align-items-center justify-content-center p-3">
                <div class="me-3">
                    <p class="m-0">Made with <span class="text-danger h3">&hearts;</span> by:</p>
                </div>
                <div class="me-3 text-center">
                    <img src="{{asset('images/logo_footer_black.png')}}" alt="" width="50px">
                    <h6>BRAINSTER</h6>
                </div>
                <div class="d-flex">
                    <p class="m-0 me-3">-</p>
                    <a href="https://www.facebook.com/brainster.co/" class="text-decoration-none text-success me-3"
                       target="_blank">Say Hi!</a>
                    <p class="m-0">- Terms</p>
                </div>
            </div>
        </div>
    </div>
</footer>
