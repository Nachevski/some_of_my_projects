<div class="modal fade" id="employeeModal" tabindex="-1" aria-labelledby="employeeModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Вработи наши студенти</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div id="validationErrors"></div>
            <div class="modal-body">
                <p>Внесете ваши информации за да стапиме во контакт:</p>
                <form action="{{route('new.employee')}}" method="POST" id="employeeForm">
                    @csrf
                    <div class="mb-3">
                        <label for="email" class="form-label">Е-мејл</label>
                        <input type="email" class="form-control" id="email" name="email">
                        <small style="color: red">**Користете постоечки мејл, за да добиете
                            конфирмација!</small>
                    </div>

                    <div class="mb-3">
                        <label for="phone" class="form-label">Телефон</label>
                        <input type="text" class="form-control" id="phone" name="phone">
                    </div>

                    <div class="mb-3">
                        <label for="company" class="form-label">Компанија</label>
                        <input type="text" class="form-control" id="company" name="company">
                    </div>
                    <button type="submit" class="btn btn-warning w-100" id="employeeFormSubmit">Испрати</button>
                </form>
            </div>
        </div>
    </div>
</div>
