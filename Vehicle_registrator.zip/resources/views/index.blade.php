@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-5">
        <div class="row">
            <div class="col-8 mx-auto">
                @include('custom-layout.components.success-msgs')
                <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#createModal">Create new
                </button>
                <table class="table">
                    <thead>
                    <tr>
                        <th scope="col">Brand</th>
                        <th scope="col">Model</th>
                        <th scope="col">Plate Number</th>
                        <th scope="col">Insurance date</th>
                        <th scope="col" style="width:150px">Actions</th>
                    </tr>
                    </thead>
                    <tbody id="vehiclesTable">
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    @include('custom-layout.components.edit-modal')
    @include('custom-layout.components.create-modal')
@endsection
