<?php

namespace Database\Factories;

use Faker\Provider\Fakecar;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Vehicle>
 */
class VehicleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $faker = (new \Faker\Factory())::create();
        $faker->addProvider(new Fakecar($faker));
        $newCar = $faker->vehicleArray;

        return [
            'brand' => $newCar['brand'],
            'model' => $newCar['model'],
            'plate_number' => $faker->vehicleRegistration,
            'insurance_date' => $faker->date(),
        ];
    }
}
