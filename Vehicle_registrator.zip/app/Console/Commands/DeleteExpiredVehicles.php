<?php

namespace App\Console\Commands;

use App\Models\Vehicle;
use Illuminate\Console\Command;

class DeleteExpiredVehicles extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'delete:expiredVehicles';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Delete vehicles that are soft deleted and has expired insurance';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $vehicles = Vehicle::onlyTrashed()->orWhere('insurance_date', '<', now())->forceDelete();
        $this->info($vehicles);
        info('Total ' . $vehicles . ' expired vehicles deleted successfully on: ' . now());
    }
}
