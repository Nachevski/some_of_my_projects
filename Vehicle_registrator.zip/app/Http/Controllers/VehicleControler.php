<?php

namespace App\Http\Controllers;

use App\Http\Requests\VehicleRequest;
use App\Models\Vehicle;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class VehicleControler extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $vehicles = Vehicle::all();
        return response()->json($vehicles);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(VehicleRequest $request)
    {
        Vehicle::create($request->all());
        return response()->json([
            'status' => true,
            'message' => "Successfully updated: $request->brand $request->model with plate number: $request->plate_number"
        ]);

    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Vehicle $vehicle)
    {
        return response()->json($vehicle);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(VehicleRequest $request, Vehicle $vehicle)
    {
        $vehicle->update($request->all());
        return response()->json([
            'status' => true,
            'message' => "Successfully updated: $vehicle->brand $vehicle->model with plate number: $vehicle->plate_number"
        ]);

    }

    /**
     * Remove the specified resource from storage.
     * @param Vehicle $vehicleID
     */
    public function destroy(Vehicle $vehicle)
    {
//        dd($vehicle);
        $vehicle->delete();
        return response()->json([
            'status' => true,
            'message' => "Successfully deleted: $vehicle->brand $vehicle->model with plate number: $vehicle->plate_number"
        ]);
    }

    public function extendRegistration(Vehicle $vehicle)
    {
        $vehicle->insurance_date = Carbon::now()->addYear();
        $vehicle->save();
        return response()->json([
            'status' => true,
            'message' => "Successfully extended registration for: $vehicle->brand $vehicle->model with plate number: $vehicle->plate_number"
        ]);
    }
}
