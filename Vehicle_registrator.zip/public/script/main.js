$(function () {
    loadVehicles()

    function loadVehicles() {
        $.get('api/vehicles', function (data) {
            let table = $('#vehiclesTable').empty()
            data.forEach(element => {
                let row = `<tr>
                                <td>${element.brand}</td>
                                <td>${element.model}</td>
                                <td>${element.plate_number}</td>
                                <td>${(element.insurance_date) ? element.insurance_date : 'Not Registered'}</td>
                                <td class="d-flex" style="width: fit-content">
                                    <button data-id="${element.id}" class="btn btn-danger me-2 btn-delete">Delete</button>
                                    <button data-id="${element.id}" class="btn btn-warning btn-edit me-2" data-bs-toggle="modal" data-bs-target="#editModal">Edit</button>
                                    ${(element.insurance_date == null) ? `<button data-id="${element.id}" class="btn btn-info me-2 btn-extendRegistration">Registrate</button>` : ''}
                                </td>
                            </tr>`
                table.append(row);
            })
            $('.btn').on('click', function (e) {
                if ($(this).hasClass('btn-delete')) {
                    deleteRecord($(this).data('id'), $(this))
                } else if ($(this).hasClass('btn-edit')) {
                    editRecord($(this).data('id'))
                } else if ($(this).hasClass('btn-extendRegistration')) {
                    extendRegistration($(this).data('id'))
                }
            })
        })
    }

    function deleteRecord(vehicleID, rowRecord) {
        $.ajax({
            url: `/api/vehicles/${vehicleID}`,
            type: 'DELETE',
            success: function (response) {
                showResponseStatus(response)
                rowRecord.closest('tr').remove()
            }
        });
    }

    function editRecord(vehicleID) {
        $.get(`api/vehicles/${vehicleID}/edit`, function (response) {
            $('#editForm .brand').val(response.brand)
            $('#editForm .model').val(response.model)
            $('#editForm .plateNumber').val(response.plate_number)
            // $('#editForm .insuranceDate').val(response.insurance_date)
            $('#editForm').attr('data-id', response.id)
            console.log(response)
        })
    }

    $('#editForm').submit(function (e) {
        e.preventDefault();
        let activeRecord = $('#editForm').attr('data-id')
        $.ajax({
            url: `api/vehicles/${activeRecord}`,
            type: 'PATCH',
            data: $('#editForm').serialize(),
        }).done(function (response) {
            if (!response.status) {
                let errorShow = $('#editModal .errors').empty()
                errorShow.append(generateErrors(response.errors))
            } else {
                $('#editModal').modal('toggle');
                showResponseStatus(response)
                loadVehicles();
            }
        })
    })


    $('#createForm').submit(function (e) {
        e.preventDefault();
        $.ajax({
            url: `api/vehicles`,
            type: 'POST',
            data: $('#createForm').serialize(),
        }).done(function (response) {
            if (!response.status) {
                let errorShow = $('#createModal .errors').empty()
                errorShow.append(generateErrors(response.errors))
            } else {
                $('#createModal').modal('toggle');
                showResponseStatus(response)
                loadVehicles();
            }
        })
    })

    function extendRegistration(vehicleID) {
        $.ajax({
            url: `/api/vehicles/${vehicleID}/extendRegistration`,
            type: 'PUT',
        }).done(function (response) {
            if (!response.status) {
                let errorShow = $('#editModal .errors').empty()
                errorShow.append(generateErrors(response.errors))
            } else {
                showResponseStatus(response)
                loadVehicles();
            }
        })
    }

    function showResponseStatus(response) {
        $('.alert ')
            .fadeIn(100)
            .html(response.message)
            .fadeOut(10000)
    }

    function generateErrors(errors) {
        let report = Object.values(errors)
        let ul = '';
        report.forEach(element => {
            ul += `<li>${element}</li>`
        })
        return ul;
    }
})
