<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <div class="container-md">
        <a class="navbar-brand" href="<?php echo e(route('index')); ?>">Vehicle Registration</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="flex-grow-0 d-flex">
            <div class="collapse navbar-collapse flex-grow-0" id="navbarNavDropdown">
                <?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userOptions" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userOptions">
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log Out</a></li>
                            </ul>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /home/nachevski/Desktop/Challenge_27/Challenge_27/resources/views/custom-layout/navbar.blade.php ENDPATH**/ ?>