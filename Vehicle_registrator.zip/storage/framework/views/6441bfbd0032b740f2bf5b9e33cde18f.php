<div class="alert alert-success text-center " role="alert" style="display: none">
</div>
<?php /**PATH /home/nachevski/Desktop/Challenge_27/Challenge_27/resources/views/custom-layout/components/success-msgs.blade.php ENDPATH**/ ?>