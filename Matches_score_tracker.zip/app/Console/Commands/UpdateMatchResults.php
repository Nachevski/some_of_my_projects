<?php

namespace App\Console\Commands;

use App\Models\Matchh;
use Illuminate\Console\Command;

class UpdateMatchResults extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'matchResults:update';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updating match results once a day';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $upCommingMatches = Matchh::where('scheduled_at', '<', now())
            ->where('home_team_score', '=', '-')
            ->get();
        if (isset($upCommingMatches[0])) {
            foreach ($upCommingMatches as $match) {
                $match->update([
                    'home_team_score' => rand(0, 10),
                    'guest_team_score' => rand(0, 10)
                ]);
            }
        }
        $this->info('Command executed successfully!');
        $this->info('Total: ' . count($upCommingMatches) . ' matches were updated!');
        info('Total ' . count($upCommingMatches) . ' Matches updated successfully on: ' . now());
    }
}
