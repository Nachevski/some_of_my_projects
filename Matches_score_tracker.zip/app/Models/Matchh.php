<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Matchh extends Model
{
    use HasFactory;

    protected $table = 'matches';
    protected $fillable = [
        'home_team',
        'home_team_score',
        'guest_team',
        'guest_team_score',
        'scheduled_at'
    ];

    public function homeTeam()
    {
        return $this->belongsTo(Team::class, 'home_team', 'id');
    }

    public function guestTeam()
    {
        return $this->belongsTo(Team::class, 'guest_team', 'id');
    }

    public function players()
    {
        $this->hasMany(Player::class);
    }
}
