<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlayerStats extends Model
{
    use HasFactory;

    protected $fillable = [
        'player_id',
        'match_id',
        'team_id'
    ];

    public function team()
    {
        return $this->hasMany(Team::class, "id", "team_id");
    }

    public function matchh()
    {
        return $this->hasMany(Matchh::class, "id", "match_id");
    }

    public function players()
    {
        return $this->hasMany(Player::class, "id", "player_id");
    }
}
