<?php

namespace App\Http\Controllers;

use App\Http\Requests\TeamRequest;
use App\Models\Team;
use Illuminate\Http\Request;

class TeamController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $teams = Team::all();
        return view('teams', compact('teams'));

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('teams');

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(TeamRequest $request)
    {
        Team::create($request->all());
        return redirect('teams')->with('successStatus', 'Team successfully added!');

    }

    /**
     * Display the specified resource.
     */
    public function show(Team $team)
    {
        return view('teams', compact('team'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Team $team)
    {
        return view('teams', compact('team'));
    }

    /**
     * Update the specified resource in storage.
     * @param TeamRequest $request
     * @param Team $team
     */
    public function update(TeamRequest $request, Team $team)
    {
        $team->update($request->all());
        return redirect('teams')->with('successStatus', 'Team successfully updated!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Team $team)
    {
        $team->delete();
        return redirect('teams')->with('successStatus', 'Team successfully deleted!');

    }
}
