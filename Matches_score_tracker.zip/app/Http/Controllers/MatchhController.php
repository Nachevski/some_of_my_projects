<?php

namespace App\Http\Controllers;

use App\Http\Requests\MatchRequest;
use App\Models\Matchh;
use App\Models\Player;
use App\Models\PlayerStats;
use App\Models\Team;
use Illuminate\Http\Request;

class MatchhController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $teams = Team::all();
        return view('matches', compact('teams'));
    }

    /**
     * Store a newly created resource in storage.
     * @param MatchRequest $request
     */
    public function store(MatchRequest $request)
    {
        $newMatch = Matchh::create($request->all());
        $homePlayers = Player::where("team_id", $request->home_team)->get();
        $awayPlayers = Player::where("team_id", $request->guest_team)->get();
        $collectedPlayers = $this->collectPlayers(compact('homePlayers', 'awayPlayers'), $newMatch);
        PlayerStats::insert($collectedPlayers);
        return redirect('matches')->with('successStatus', 'New match created successfully!');
    }

    public function collectPlayers($teams, Matchh $newMatch)
    {
        $matchPlayers = [];
        foreach ($teams as $team) {
            foreach ($team as $player) {
                $matchPlayers[] = [
                    "player_id" => $player->id,
                    "match_id" => $newMatch->id,
                    "team_id" => $player->team_id
                ];
            }
        }
        return $matchPlayers;
    }

    /**
     * Display the specified resource.
     */
    public function show(Matchh $matchh)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Matchh $match)
    {
        $teams = Team::all();
        return view('matches', compact('match', 'teams'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(MatchRequest $request, Matchh $match)
    {
        $homePlayers = Player::where("team_id", $request->home_team)->get();
        $awayPlayers = Player::where("team_id", $request->guest_team)->get();
        $collectedPlayers = $this->collectPlayers(compact('homePlayers', 'awayPlayers'), $match);
        $match->update($request->all());
        PlayerStats::where('match_id', $match->id)->delete();
        PlayerStats::insert($collectedPlayers);
        return redirect('matches')->with('successStatus', 'New match created successfully!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Matchh $match)
    {
        PlayerStats::where('match_id', $match->id)->delete();
        $match->delete();
        return redirect('matches')->with('successStatus', 'Match successfully deleted');
    }

    public function quest()
    {
        $matches = Matchh::all();
        return view('matches', compact('matches'));
    }
}
