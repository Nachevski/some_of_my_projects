<?php

namespace Database\Seeders;

use App\Models\Team;
use Faker\Factory as Faker;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PlayerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
//        ADDING RANDOM 11 PLAYERS FOR EACH TEAM
        $faker = Faker::create();
        $teams = Team::all();
        foreach ($teams as $team) {
            for ($j = 1; $j <= 11; $j++) {
                $players [] = [
                    'name' => $faker->firstName(),
                    'surname' => $faker->lastName(),
                    'birth_date' => $faker->date(),
                    'team_id' => $team->id,
                ];;
            }
        }
        DB::table('players')->insert($players);
    }
}
