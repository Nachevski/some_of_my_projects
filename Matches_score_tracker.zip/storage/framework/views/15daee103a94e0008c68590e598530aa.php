<?php $__env->startSection('content'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-8 mx-auto border p-0">
                <?php if(Route::is('teams.index')): ?>
                    <?php echo $__env->make('custom-layout.app.list-teams', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('teams.create')): ?>
                    <?php echo $__env->make('custom-layout.app.create-team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('teams.edit')): ?>
                    <?php echo $__env->make('custom-layout.app.edit-team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('teams.show')): ?>
                    <?php echo $__env->make('custom-layout.app.view-team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/teams.blade.php ENDPATH**/ ?>