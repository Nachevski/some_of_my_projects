<?php if($errors->any()): ?>
    <ul class="alert alert-danger" role="alert">
        <div class="ps-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </ul>
<?php endif; ?>
<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/components/error-msgs.blade.php ENDPATH**/ ?>