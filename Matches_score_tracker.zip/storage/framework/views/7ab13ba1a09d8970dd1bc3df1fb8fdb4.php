<?php $__env->startSection('content'); ?>


    <div class="container-fluid mt-3">
        <div class="row">

            <div class="col-8 mx-auto border p-0">
                <div class="bg-light p-3 d-flex justify-content-between">
                    <p class="m-0">Matches</p>

                </div>
                <div class="p-3">
                    <?php if (Auth::user()->isAdmin()): ?>
                        <a href="<?php echo e(route('match.create')); ?>" class="btn btn-primary">Add new match</a>
                    <?php endif; ?>
                    <table class="table px-2">
                        <thead>
                        <tr>
                            <th scope="col">Home Team</th>
                            <th scope="col">Result</th>
                            <th scope="col">Guest Team</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true;
                        $__currentLoopData = $matches;
                        $__env->addLoop($__currentLoopData);
                        foreach ($__currentLoopData as $match): $__env->incrementLoopIndices();
                            $loop = $__env->getLastLoop();
                            $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($match->homeTeam->name); ?></td>
                                <td><?php echo e($match->home_team_score . ' : ' . $match->quest_team_score); ?></td>
                                <td><?php echo e($match->guestTeam->name); ?></td>
                            </tr>
                        <?php endforeach;
                        $__env->popLoop();
                        $loop = $__env->getLastLoop();
                        if ($__empty_1): ?>
                            <h4 class="text-center m-5">No scheduled matches for today!</h4>
                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/matches.blade.php ENDPATH**/ ?>
