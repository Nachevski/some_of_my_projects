<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-8 mx-auto border p-0">
                <?php if(Route::is('players.index')): ?>
                    <?php echo $__env->make('custom-layout.app.list-players', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('players.create')): ?>
                    <?php echo $__env->make('custom-layout.app.create-player', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('players.edit')): ?>
                    <?php echo $__env->make('custom-layout.app.edit-player', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('players.show')): ?>
                    <?php echo $__env->make('custom-layout.app.view-player-stats', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/players.blade.php ENDPATH**/ ?>