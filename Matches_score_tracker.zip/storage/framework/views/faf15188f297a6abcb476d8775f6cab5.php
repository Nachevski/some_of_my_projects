<?php $__env->startSection('content'); ?>
    <h1 class="text-center p-5">Login to view matches</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/index.blade.php ENDPATH**/ ?>