<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Matches</p>
</div>

<?php echo $__env->make('custom-layout.components.error-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('match.store')); ?>" method="POST" class="p-4">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="homeTeam" class="form-label">Home Team</label>
        <select name="home_team" id="homeTeam" class="form-select ">
            <option value="">Please Select Home team</option>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="guest_team" class="form-label">Guest Team</label>
        <select name="guest_team" id="guest_team" class="form-select ">
            <option value="">Please Select Guest team</option>
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($team->id); ?>"><?php echo e($team->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3">
        <label for="scheduled_at" class="form-label">Date</label>
        <input type="datetime-local" class="form-control" id="scheduled_at" name="scheduled_at">
    </div>
    <button type="submit" class="btn btn-success me-3">Save</button>
    <a href="<?php echo e(route('matches')); ?>" class="btn btn-secondary">Back</a>

</form>
<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/create-match.blade.php ENDPATH**/ ?>