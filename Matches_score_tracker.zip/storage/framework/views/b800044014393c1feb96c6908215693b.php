<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Team players</p>
    <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-primary">Back</a>

</div>
<div class="p-3">
    <h4>Team name: <?php echo e($team->name); ?></h4>
    <h4>Founded: <?php echo e($team->foundation_year); ?></h4>

    <table class="table px-2 mt-3">
        <thead>
        <tr>
            <th scope="col">Player name</th>
            <th scope="col">Player surname</th>
            <th scope="col">Birth date</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $team->players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($player->name); ?></td>
                <td><?php echo e($player->surname); ?></td>
                <td><?php echo e($player->birth_date); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/view-team.blade.php ENDPATH**/ ?>