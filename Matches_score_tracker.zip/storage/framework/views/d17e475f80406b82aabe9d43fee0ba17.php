<?php if(Session::has('successStatus')): ?>
    <div class="alert alert-success text-center" role="alert">
        <?php echo e(Session::get('successStatus')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/components/success-msgs.blade.php ENDPATH**/ ?>