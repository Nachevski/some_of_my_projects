<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <div class="container-md">
        <a class="navbar-brand" href="<?php echo e(route('matches')); ?>">LiveScore</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="flex-grow-0 d-flex">
            <div class="collapse navbar-collapse flex-grow-0" id="navbarNavDropdown">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('matches')); ?>" class="nav-link me-3">Matches</a>
                    <?php if(Auth::user()->isAdmin()): ?>
                        <a href="<?php echo e(route('teams.index')); ?>" class="nav-link me-3">Teams</a>
                        <a href="<?php echo e(route('players.index')); ?>" class="nav-link me-3">Players</a>
                    <?php endif; ?>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userOptions" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?>

                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userOptions">
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log Out</a></li>
                            </ul>
                        </li>
                    </ul>
                <?php else: ?>
                    <a href="/login" class="nav-link me-2">Login</a>
                    <a href="/register" class="nav-link ">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/navbar.blade.php ENDPATH**/ ?>