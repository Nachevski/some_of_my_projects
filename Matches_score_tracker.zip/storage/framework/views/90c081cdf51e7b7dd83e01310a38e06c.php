<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Edit Team</p>
</div>

<?php echo $__env->make('custom-layout.components.error-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form action="<?php echo e(route('teams.update',$team->id)); ?>" method="POST" class="p-4">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name',$team->name)); ?>">
    </div>
    <div class="mb-3">
        <label for="foundation_year" class="form-label">Foundation Year</label>
        <input type="text" class="form-control" id="foundation_year" name="foundation_year"
               value="<?php echo e(old('foundation_year',$team->foundation_year)); ?>">
    </div>
    <button type="submit" class="btn btn-success me-3">Save</button>
    <a href="<?php echo e(route('teams.index')); ?>" class="btn btn-secondary">Back</a>
</form>

<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/edit-team.blade.php ENDPATH**/ ?>