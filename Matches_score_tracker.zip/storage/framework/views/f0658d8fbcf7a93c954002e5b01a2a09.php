<div class="bg-light p-3 d-flex justify-content-between">
    <p class="m-0">Matches</p>
</div>
<div class="p-3">
    <div class="text-end p-2">
        <?php if(Auth::user()->isAdmin()): ?>
            <a href="<?php echo e(route('match.create')); ?>" class="btn btn-primary">Add new match</a>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('custom-layout.components.success-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <table class="table px-2">
        <thead>
        <tr>
            <th scope="col">Home Team</th>
            <th scope="col">Result</th>
            <th scope="col">Guest Team</th>
            <th scope="col">Schedule date</th>
            <?php if(Auth::user()->isAdmin()): ?>
                <th scope="col">Actions</th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($match->homeTeam->name); ?></td>
                <td><?php echo e($match->home_team_score . ' : ' . $match->guest_team_score); ?></td>
                <td><?php echo e($match->guestTeam->name); ?></td>
                <td><?php echo e($match->scheduled_at); ?></td>
                <?php if(Auth::user()->isAdmin()): ?>
                    <td>
                        <div class="d-flex">
                            <?php if($match->scheduled_at > now()): ?>
                                <a href="<?php echo e(route('match.edit', $match->id)); ?>" class="btn btn-warning me-2">Edit</a>
                            <?php else: ?>
                                <button class="btn  me-2" disabled>
                                    <i class="fa-solid fa-xmark"></i>
                                    Edit
                                </button>
                            <?php endif; ?>
                            <a href=""></a>
                            <form action="<?php echo e(route('match.destroy', $match->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                <?php endif; ?>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h4 class="text-center m-5">No scheduled matches for today!</h4>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/list-matches.blade.php ENDPATH**/ ?>