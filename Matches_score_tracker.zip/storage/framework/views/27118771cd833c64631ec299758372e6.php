<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Players</p>
</div>
<div class="p-3">
    <div class="text-end p-2">
        <a href="<?php echo e(route('players.create')); ?>" class="btn btn-primary">Add new player</a>
    </div>
    <?php echo $__env->make('custom-layout.components.success-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table px-2">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Date of birth</th>
            <th scope="col">Team</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($player->name . ' ' . $player->surname); ?></td>
                <td><?php echo e($player->birth_date); ?></td>
                <td><?php echo e($player->team->name); ?></td>
                <td>
                    <div class="d-flex">
                        <a href="<?php echo e(route('players.show', $player->id)); ?>" class="btn btn-info me-2">Stats</a>
                        <a href="<?php echo e(route('players.edit', $player->id)); ?>" class="btn btn-warning me-2">Edit</a>
                        <a href=""></a>
                        <form action="<?php echo e(route('players.destroy', $player->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h4 class="text-center m-5">No players found!</h4>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/list-players.blade.php ENDPATH**/ ?>