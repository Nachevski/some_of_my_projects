<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Teams</p>
</div>
<div class="p-3">
    <div class="text-end p-2">
        <a href="<?php echo e(route('teams.create')); ?>" class="btn btn-primary">Create new Team</a>
    </div>
    <?php echo $__env->make('custom-layout.components.success-msgs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table px-2">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Year Founded</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($team->name); ?></td>
                <td><?php echo e($team->foundation_year); ?></td>
                <td>
                    <div class="d-flex">
                        <a href="<?php echo e(route('teams.show', $team->id)); ?>" class="btn btn-info me-2">View</a>
                        <a href="<?php echo e(route('teams.edit', $team->id)); ?>" class="btn btn-warning me-2">Edit</a>
                        <form action="<?php echo e(route('teams.destroy', $team->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h4 class="text-center m-5">No teams found!</h4>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/list-teams.blade.php ENDPATH**/ ?>