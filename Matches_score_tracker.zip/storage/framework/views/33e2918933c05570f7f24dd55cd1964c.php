<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-3 ">
        <div class="row">
            <div class="col-8 mx-auto border p-0">
                <?php if(Route::is('matches')): ?>
                    <?php echo $__env->make('custom-layout.app.list-matches', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('match.create')): ?>
                    <?php echo $__env->make('custom-layout.app.create-match', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                <?php if(Route::is('match.edit')): ?>
                    <?php echo $__env->make('custom-layout.app.edit-match', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom-layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/matches.blade.php ENDPATH**/ ?>