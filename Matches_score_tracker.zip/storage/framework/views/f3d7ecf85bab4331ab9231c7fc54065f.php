<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Player statistics</p>
    <a href="<?php echo e(route('players.index')); ?>" class="btn btn-primary">Back</a>
</div>
<div class="p-3">
    <h4>Name: <?php echo e($player->name . ' '. $player->surname); ?></h4>
    <h4>Current team: <?php echo e($player->team->name); ?></h4>
    <table class="table px-2 mt-3">
        <thead>
        <tr>
            <th scope="col">Home Team</th>
            <th scope="col">Result</th>
            <th scope="col">Guest Team</th>
            <th scope="col">Schedule date</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $player->stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($info->matchh[0]->homeTeam->name); ?></td>
                <td><?php echo e($info->matchh[0]->home_team_score . ' : '. $info->matchh[0]->guest_team_score); ?></td>
                <td><?php echo e($info->matchh[0]->guestTeam->name); ?></td>
                <td><?php echo e($info->matchh[0]->scheduled_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h5 class="text-center text-danger my-5">No played matches for this player!</h5>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php /**PATH /home/nachevski/Desktop/Challenge_26/Challenge_26/resources/views/custom-layout/app/view-player-stats.blade.php ENDPATH**/ ?>