@extends('custom-layout.master')

@section('content')

@section('content')
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-8 mx-auto border p-0">
                @if(Route::is('teams.index'))
                    @include('custom-layout.app.list-teams')
                @endif
                @if(Route::is('teams.create'))
                    @include('custom-layout.app.create-team')
                @endif
                @if(Route::is('teams.edit'))
                    @include('custom-layout.app.edit-team')
                @endif
                @if(Route::is('teams.show'))
                    @include('custom-layout.app.view-team')
                @endif
            </div>
        </div>
    </div>
@endsection

@endsection
