@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-3 ">
        <div class="row">
            <div class="col-8 mx-auto border p-0">
                @if(Route::is('matches'))
                    @include('custom-layout.app.list-matches')
                @endif
                @if(Route::is('match.create'))
                    @include('custom-layout.app.create-match')
                @endif
                @if(Route::is('match.edit'))
                    @include('custom-layout.app.edit-match')
                @endif
            </div>
        </div>
    </div>
@endsection
