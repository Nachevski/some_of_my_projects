@if ($errors->any())
    <ul class="alert alert-danger" role="alert">
        <div class="ps-5">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </div>
    </ul>
@endif
