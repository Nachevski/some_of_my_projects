<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Team players</p>
    <a href="{{route('teams.index')}}" class="btn btn-primary">Back</a>

</div>
<div class="p-3">
    <h4>Team name: {{$team->name}}</h4>
    <h4>Founded: {{$team->foundation_year}}</h4>

    <table class="table px-2 mt-3">
        <thead>
        <tr>
            <th scope="col">Player name</th>
            <th scope="col">Player surname</th>
            <th scope="col">Birth date</th>
        </tr>
        </thead>
        <tbody>
        @foreach($team->players as $player)
            <tr>
                <td>{{$player->name}}</td>
                <td>{{$player->surname}}</td>
                <td>{{$player->birth_date}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>

