<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Players</p>
</div>
<div class="p-3">
    <div class="text-end p-2">
        <a href="{{route('players.create')}}" class="btn btn-primary">Add new player</a>
    </div>
    @include('custom-layout.components.success-msgs')
    <table class="table px-2">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Date of birth</th>
            <th scope="col">Team</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        @forelse($players as $player)
            <tr>
                <td>{{$player->name . ' ' . $player->surname}}</td>
                <td>{{$player->birth_date}}</td>
                <td>{{$player->team->name}}</td>
                <td>
                    <div class="d-flex">
                        <a href="{{route('players.show', $player->id)}}" class="btn btn-info me-2">Stats</a>
                        <a href="{{route('players.edit', $player->id)}}" class="btn btn-warning me-2">Edit</a>
                        <a href=""></a>
                        <form action="{{route('players.destroy', $player->id)}}" method="POST">
                            @csrf
                            @method('delete')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
        @empty
            <h4 class="text-center m-5">No players found!</h4>
        @endforelse
        </tbody>
    </table>
</div>

