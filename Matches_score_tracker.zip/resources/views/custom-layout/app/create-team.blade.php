<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Create new Team</p>
</div>

@include('custom-layout.components.error-msgs')

<form action="{{route('teams.store')}}" method="POST" class="p-4">
    @csrf
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="{{old('name')}}">
    </div>
    <div class="mb-3">
        <label for="foundation_year" class="form-label">Foundation Year</label>
        <input type="text" class="form-control" id="foundation_year" name="foundation_year"
               value="{{old('foundation_year')}}">
    </div>
    <button type="submit" class="btn btn-success me-3">Save</button>
    <a href="{{route('teams.index')}}" class="btn btn-secondary">Back</a>
</form>

