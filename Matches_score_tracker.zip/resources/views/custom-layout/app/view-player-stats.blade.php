<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Player statistics</p>
    <a href="{{route('players.index')}}" class="btn btn-primary">Back</a>
</div>
<div class="p-3">
    <h4>Name: {{$player->name . ' '. $player->surname}}</h4>
    <h4>Current team: {{$player->team->name}}</h4>
    <table class="table px-2 mt-3">
        <thead>
        <tr>
            <th scope="col">Home Team</th>
            <th scope="col">Result</th>
            <th scope="col">Guest Team</th>
            <th scope="col">Schedule date</th>
        </tr>
        </thead>
        <tbody>
        @forelse($player->stats as $info)
            <tr>
                <td>{{$info->matchh[0]->homeTeam->name}}</td>
                <td>{{$info->matchh[0]->home_team_score . ' : '. $info->matchh[0]->guest_team_score}}</td>
                <td>{{$info->matchh[0]->guestTeam->name}}</td>
                <td>{{$info->matchh[0]->scheduled_at}}</td>
            </tr>
        @empty
            <h5 class="text-center text-danger my-5">No played matches for this player!</h5>
        @endforelse
        </tbody>
    </table>
</div>

