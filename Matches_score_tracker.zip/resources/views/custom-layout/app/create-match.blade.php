<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Matches</p>
</div>

@include('custom-layout.components.error-msgs')

<form action="{{route('match.store')}}" method="POST" class="p-4">
    @csrf
    <div class="mb-3">
        <label for="homeTeam" class="form-label">Home Team</label>
        <select name="home_team" id="homeTeam" class="form-select ">
            <option value="">Please Select Home team</option>
            @foreach($teams as $team)
                <option value="{{$team->id}}">{{$team->name}}</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label for="guest_team" class="form-label">Guest Team</label>
        <select name="guest_team" id="guest_team" class="form-select ">
            <option value="">Please Select Guest team</option>
            @foreach($teams as $team)
                <option value="{{$team->id}}">{{$team->name}}</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label for="scheduled_at" class="form-label">Date</label>
        <input type="datetime-local" class="form-control" id="scheduled_at" name="scheduled_at">
    </div>
    <button type="submit" class="btn btn-success me-3">Save</button>
    <a href="{{route('matches')}}" class="btn btn-secondary">Back</a>

</form>
