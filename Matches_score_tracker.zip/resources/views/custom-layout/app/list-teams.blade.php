<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Teams</p>
</div>
<div class="p-3">
    <div class="text-end p-2">
        <a href="{{route('teams.create')}}" class="btn btn-primary">Create new Team</a>
    </div>
    @include('custom-layout.components.success-msgs')
    <table class="table px-2">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Year Founded</th>
            <th scope="col">Actions</th>
        </tr>
        </thead>
        <tbody>
        @forelse($teams as $team)
            <tr>
                <td>{{$team->name}}</td>
                <td>{{$team->foundation_year}}</td>
                <td>
                    <div class="d-flex">
                        <a href="{{route('teams.show', $team->id)}}" class="btn btn-info me-2">View</a>
                        <a href="{{route('teams.edit', $team->id)}}" class="btn btn-warning me-2">Edit</a>
                        <form action="{{route('teams.destroy', $team->id)}}" method="POST">
                            @csrf
                            @method('delete')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
        @empty
            <h4 class="text-center m-5">No teams found!</h4>
        @endforelse
        </tbody>
    </table>
</div>

