<div class="bg-light p-4 d-flex justify-content-between">
    <p class="m-0">Players</p>
</div>

@include('custom-layout.components.error-msgs')

<form action="{{route('players.update',$player->id)}}" method="POST" class="p-4">
    @csrf
    @method('put')
    <div class="mb-3">
        <label for="name" class="form-label">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="{{old('name',$player->name)}}">
    </div>
    <div class="mb-3">
        <label for="surname" class="form-label">Surname</label>
        <input type="text" class="form-control" id="surname" name="surname" value="{{old('surname',$player->surname)}}">
    </div>
    <div class="mb-3">
        <label for="birth_date" class="form-label">Date of birth</label>
        <input type="text" class="form-control" id="birth_date" name="birth_date"
               value="{{old('birth_date', $player->birth_date)}}">
    </div>

    <div class="mb-3">
        <label for="team_id" class="form-label">Guest Team</label>
        <select name="team_id" id="team_id" class="form-select ">
            @foreach($teams as $team)
                @if($team->name == $player->team->name)
                    <option value="{{$team->id}}" selected>{{$team->name}}</option>
                @else
                    <option value="{{$team->id}}">{{$team->name}}</option>
                @endif
            @endforeach
        </select>
    </div>

    <button type="submit" class="btn btn-success me-3">Save</button>
    <a href="{{route('players.index')}}" class="btn btn-secondary">Back</a>
</form>

