<div class="bg-light p-3 d-flex justify-content-between">
    <p class="m-0">Matches</p>
</div>
<div class="p-3">
    <div class="text-end p-2">
        @if(Auth::user()->isAdmin())
            <a href="{{route('match.create')}}" class="btn btn-primary">Add new match</a>
        @endif
    </div>

    @include('custom-layout.components.success-msgs')

    <table class="table px-2">
        <thead>
        <tr>
            <th scope="col">Home Team</th>
            <th scope="col">Result</th>
            <th scope="col">Guest Team</th>
            <th scope="col">Schedule date</th>
            @if(Auth::user()->isAdmin())
                <th scope="col">Actions</th>
            @endif
        </tr>
        </thead>
        <tbody>
        @forelse($matches as $match)
            <tr>
                <td>{{$match->homeTeam->name}}</td>
                <td>{{$match->home_team_score . ' : ' . $match->guest_team_score}}</td>
                <td>{{$match->guestTeam->name}}</td>
                <td>{{$match->scheduled_at}}</td>
                @if(Auth::user()->isAdmin())
                    <td>
                        <div class="d-flex">
                            @if($match->scheduled_at > now())
                                <a href="{{route('match.edit', $match->id)}}" class="btn btn-warning me-2">Edit</a>
                            @else
                                <button class="btn  me-2" disabled>
                                    <i class="fa-solid fa-xmark"></i>
                                    Edit
                                </button>
                            @endif
                            <a href=""></a>
                            <form action="{{route('match.destroy', $match->id)}}" method="POST">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                @endif

            </tr>
        @empty
            <h4 class="text-center m-5">No scheduled matches for today!</h4>
        @endforelse
        </tbody>
    </table>
</div>

