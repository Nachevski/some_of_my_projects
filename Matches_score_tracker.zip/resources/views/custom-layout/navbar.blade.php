<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <div class="container-md">
        <a class="navbar-brand" href="{{route('matches')}}">LiveScore</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="flex-grow-0 d-flex">
            <div class="collapse navbar-collapse flex-grow-0" id="navbarNavDropdown">
                @auth
                    <a href="{{route('matches')}}" class="nav-link me-3">Matches</a>
                    @if(Auth::user()->isAdmin())
                        <a href="{{route('teams.index')}}" class="nav-link me-3">Teams</a>
                        <a href="{{route('players.index')}}" class="nav-link me-3">Players</a>
                    @endif
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userOptions" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">
                                {{Auth::user()->name}}
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="userOptions">
                                <li><a class="dropdown-item" href="{{ route('logout') }}">Log Out</a></li>
                            </ul>
                        </li>
                    </ul>
                @else
                    <a href="/login" class="nav-link me-2">Login</a>
                    <a href="/register" class="nav-link ">Register</a>
                @endauth
            </div>
        </div>
    </div>
</nav>
