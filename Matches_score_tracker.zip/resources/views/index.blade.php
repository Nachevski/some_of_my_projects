@extends('custom-layout.master')

@section('content')
    <h1 class="text-center p-5">Login to view matches</h1>
@endsection
