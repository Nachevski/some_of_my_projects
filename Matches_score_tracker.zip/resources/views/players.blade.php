{{--{{$matches}}--}}
@extends('custom-layout.master')

@section('content')
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-8 mx-auto border p-0">
                @if(Route::is('players.index'))
                    @include('custom-layout.app.list-players')
                @endif
                @if(Route::is('players.create'))
                    @include('custom-layout.app.create-player')
                @endif
                @if(Route::is('players.edit'))
                    @include('custom-layout.app.edit-player')
                @endif
                @if(Route::is('players.show'))
                    @include('custom-layout.app.view-player-stats')
                @endif
            </div>
        </div>
    </div>
@endsection
